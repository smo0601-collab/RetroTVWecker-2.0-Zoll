#pragma once
#include <nvs.h>
/*
  Einstellungsseite im Browser (WebServer, Port 80).

  Wird in WetterUhr.ino NACH den Definitionen von gSet, setBrightness(),
  applyTimezone(), getWeather(), timeValid(), staleMs() usw. eingebunden.

  Sicherheit: Ohne Web-Passwort ist die Seite im Heimnetz fuer jeden erreichbar.
  Setze daher ein Web-Passwort (Benutzername: admin). Das WLAN-Passwort wird
  nie an den Browser zurueckgegeben. HTTP ist unverschluesselt.
*/
#include <WebServer.h>
#include <ESPmDNS.h>

static WebServer server(80);
static bool      needReboot = false;
static uint32_t  rebootAt = 0;
static bool      mdnsStarted = false;

struct TzEntry { const char* name; const char* posix; };
static const TzEntry TZS[] = {
  {"Berlin, Paris, Roma, Madrid (CET/CEST)", "CET-1CEST,M3.5.0,M10.5.0/3"},
  {"London, Dublin (GMT/BST)",                "GMT0BST,M3.5.0/1,M10.5.0"},
  {"Lisboa, Canarias (WET/WEST)",                      "WET0WEST,M3.5.0/1,M10.5.0"},
  {"Athina, Helsinki (EET/EEST)",         "EET-2EEST,M3.5.0/3,M10.5.0/4"},
  {"Moskva (MSK)",                        "MSK-3"},
  {"New York (EST/EDT)",             "EST5EDT,M3.2.0,M11.1.0"},
  {"Chicago (CST/CDT)",                "CST6CDT,M3.2.0,M11.1.0"},
  {"Denver (MST/MDT)",                   "MST7MDT,M3.2.0,M11.1.0"},
  {"Los Angeles (PST/PDT)",         "PST8PDT,M3.2.0,M11.1.0"},
  {"Dubai",                                "<+04>-4"},
  {"Kolkata (IST)",                     "IST-5:30"},
  {"Tokyo (JST)",                        "JST-9"},
  {"Sydney (AEST/AEDT)",              "AEST-10AEDT,M10.1.0,M4.1.0/3"},
  {"UTC",                                  "UTC0"},
};

// ---------- Hilfsfunktionen ----------
static String esc(const String& s) {
  String o;
  o.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    switch (c) {
      case '&':  o += F("&amp;");  break;
      case '<':  o += F("&lt;");   break;
      case '>':  o += F("&gt;");   break;
      case '"':  o += F("&quot;"); break;
      case '\'': o += F("&#39;");  break;
      default:   o += c;
    }
  }
  return o;
}

static String jsonEsc(const String& s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') { o += '\\'; o += c; }
    else if ((uint8_t)c < 0x20) { /* Steuerzeichen weglassen */ }
    else o += c;
  }
  return o;
}

static String hhmm(uint16_t m) {
  char b[8];
  snprintf(b, sizeof(b), "%02u:%02u", (unsigned)(m / 60), (unsigned)(m % 60));
  return String(b);
}

static bool parseHhmm(const String& s, uint16_t& out) {
  int h = -1, m = -1;
  if (sscanf(s.c_str(), "%d:%d", &h, &m) != 2) return false;
  if (h < 0 || h > 23 || m < 0 || m > 59) return false;
  out = (uint16_t)(h * 60 + m);
  return true;
}

static bool authOk() {
  if (gSet.webPw[0] == 0) return true;
  if (server.authenticate("admin", gSet.webPw)) return true;
  server.requestAuthentication();
  return false;
}

static String cleanHost(String h) {
  h.toLowerCase();
  String o;
  for (size_t i = 0; i < h.length() && o.length() < 23; i++) {
    char c = h[i];
    if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-') o += c;
  }
  return o;
}

// ---------- Seite ----------
static const char PAGE_HEAD[] PROGMEM = R"=====(<head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Wetteruhr</title>
<style>
body{font-family:system-ui,sans-serif;background:#0d1117;color:#e6edf3;margin:0}
h1{font-size:1.3rem} h2{font-size:1rem;color:#58a6ff;margin:1.4em 0 .4em}
label{display:block;margin:.7em 0 .2em;color:#9da7b3;font-size:.9rem}
input,select{width:100%;box-sizing:border-box;padding:.55em;background:#161b22;color:#e6edf3;border:1px solid #30363d;border-radius:6px;font-size:1rem}
input[type=checkbox]{width:auto;margin-right:.5em} input[type=range]{padding:0}
button{margin-top:1em;padding:.7em 1.2em;border:0;border-radius:6px;background:#238636;color:#fff;font-size:1rem}
button.sec{background:#30363d;margin-left:.5em} button.red{background:#8e1519}
button.geo{display:block;width:100%;text-align:left;margin:.4em 0 0;padding:.5em .8em;background:#161b22;border:1px solid #30363d;font-size:.95rem}
button.geo:hover{border-color:var(--acc)} #geor{margin:.3em 0} input.hl{border-color:var(--acc)} small.err{color:#f85149}
.ok{background:#12351f;border:1px solid #238636;padding:.6em;border-radius:6px;margin:.6em 0}
.warn{background:#3a2a0a;border:1px solid #9e6a03;padding:.6em;border-radius:6px;margin:.6em 0;font-size:.9rem}
table{width:100%;font-size:.9rem} td{padding:.15em 0;vertical-align:top} td:first-child{color:#9da7b3;width:40%}
:root{--acc:#00c8ff}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:.4em}
.card{display:block;border:2px solid #30363d;border-radius:10px;padding:5px;cursor:pointer;position:relative;font-size:.85rem;color:#9da7b3;text-align:center}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:.5em 0}.chips a{border:1px solid #30363d;border-radius:16px;padding:4px 12px;font-size:.85rem;color:#9da7b3;cursor:pointer}.chips a.on{border-color:var(--acc);color:#e6edf3}.cg{display:block;margin-top:.8em;font-weight:600}.card.sel{border-color:var(--acc);color:#e6edf3}
.card input,.sw input{position:absolute;opacity:0;pointer-events:none}
.card svg{display:block;margin-bottom:3px;border-radius:6px}
.sw{display:inline-block;position:relative;width:34px;height:34px;border-radius:50%;border:3px solid #0d1117;box-shadow:0 0 0 1px #30363d;margin:4px;cursor:pointer}
.sw.sel{box-shadow:0 0 0 3px #e6edf3}
small{color:#9da7b3}
.app{display:flex;gap:18px;max-width:900px;margin:0 auto;padding:14px}
nav{display:flex;flex-direction:column;gap:4px;width:170px;flex:none;position:sticky;top:14px;align-self:flex-start}
nav a{padding:.6em .9em;border-radius:8px;color:#9da7b3;cursor:pointer;white-space:nowrap;user-select:none}
nav a.on{background:#161b22;color:#e6edf3;box-shadow:inset 3px 0 var(--acc)}
main{flex:1;min-width:0}
main h1{margin-top:.2em}
.tab{display:none}.tab.on{display:block}
.hid{position:absolute;left:-9999px;width:1px;height:1px;padding:0;margin:0;opacity:0}
#savebar{margin-top:1.4em;border-top:1px solid #30363d;padding-top:.2em}
@media(max-width:640px){
  .app{flex-direction:column;gap:6px;padding:10px}
  nav{flex-direction:row;width:auto;overflow-x:auto;position:sticky;top:0;background:#0d1117;padding:6px 0;z-index:5;border-bottom:1px solid #30363d}
  nav a.on{box-shadow:inset 0 -3px var(--acc)}
}
.sm{margin:.15em 0;padding:.25em .55em;min-width:2.2em;font-size:.95rem;background:#30363d}</style></head><body>
)=====";

static const char PAGE_JS[] PROGMEM = R"=====(<script>
const $=id=>document.getElementById(id);
$('br').oninput=e=>{
  $('bv').textContent=e.target.value;
  clearTimeout(window.bt);
  window.bt=setTimeout(()=>fetch('/brightness',{method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'v='+e.target.value}),150);
};
async function scan(){
  const b=$('sb'); b.disabled=true; b.textContent=L.scan;
  try{
    for(let i=0;i<12;i++){
      const r=await (await fetch('/scan')).json();
      if(r.state==='done'){
        $('ssids').innerHTML=r.list.map(s=>'<option value="'+s.replace(/"/g,'&quot;')+'">').join('');
        b.textContent=L.found+r.list.length; b.disabled=false; return;
      }
      await new Promise(r=>setTimeout(r,1500));
    }
  }catch(e){}
  b.textContent=L.scanb; b.disabled=false;
}
function paint(){
  const ac=document.querySelector('input[name=acc]:checked');
  if(ac) document.documentElement.style.setProperty('--acc',accHex[ac.value]);
  document.querySelectorAll('.card,.sw').forEach(c=>c.classList.toggle('sel',c.querySelector('input').checked));
}
function tkIns(ch){
  const t=document.querySelector('input[name=tk]'),a=t.selectionStart||t.value.length,b=t.selectionEnd||a;
  t.value=t.value.slice(0,a)+ch+t.value.slice(b); t.focus(); const p=a+ch.length; t.setSelectionRange(p,p);
}
function tkPlay(){
  const b=document.getElementById('tkplay'); b.disabled=true;
  fetch('/ticker',{method:'POST'}).finally(()=>setTimeout(()=>{b.disabled=false;},1500));
}
function look(){
  paint();
  const cs=document.querySelector('input[name=cs]:checked').value,
        ac=document.querySelector('input[name=acc]:checked').value;
  fetch('/look',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'cs='+cs+'&acc='+ac});
}
document.querySelectorAll('input[name=cs],input[name=acc]').forEach(i=>i.onchange=look);
paint();
// Ortssuche: erst direkt aus dem Browser (Open-Meteo), sonst ueber die Uhr (/geo)
async function geoFind(){
  const q=$('geoq').value.trim(),o=$('geor'); if(q.length<2) return;
  o.innerHTML='<small>'+L.gw+'</small>';
  const u='https://geocoding-api.open-meteo.com/v1/search?count=8&format=json&language='+L.glang+'&name='+encodeURIComponent(q);
  const get=async(x)=>{const c=new AbortController(),t=setTimeout(()=>c.abort(),8000);
    try{const r=await fetch(x,{signal:c.signal});if(!r.ok)throw 0;return await r.json();}finally{clearTimeout(t);}};
  let d=null;
  try{d=await get(u);}catch(e){try{d=await get('/geo?q='+encodeURIComponent(q));}catch(e2){}}
  if(!d||d.error){o.innerHTML='<small class=err>'+L.ge+'</small>';return;}
  const r=d.results||[];
  if(!r.length){o.innerHTML='<small>'+L.gn+'</small>';return;}
  const h=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  window.geoR=r;
  o.innerHTML=r.map((p,i)=>{const t=[p.name,p.postcodes&&p.postcodes.length?p.postcodes[0]:'',p.admin2&&p.admin2!==p.name?p.admin2:'',p.admin1,p.country].filter(x=>x).map(h).join(', ');
    return '<button type=button class=geo onclick=geoPick('+i+')><b>'+t+'</b><br><small>'+(+p.latitude).toFixed(4)+', '+(+p.longitude).toFixed(4)+(p.elevation!=null?' &middot; '+Math.round(p.elevation)+' m':'')+'</small></button>';}).join('');
}
function geoPick(i){
  const p=window.geoR[i],f=document.querySelector('input[name=lat]').form;
  f.lat.value=(+p.latitude).toFixed(4); f.lon.value=(+p.longitude).toFixed(4);
  $('geor').innerHTML='<small>'+L.gok+String(p.name).replace(/[&<>]/g,'')+(p.country?' ('+String(p.country).replace(/[&<>]/g,'')+')':'')+L.gsv+'</small>';
  f.lat.classList.add('hl'); f.lon.classList.add('hl');
}
function show(t){
  document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('on',e.id==='t-'+t));
  document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.t===t));
  $('savebar').style.display=(t==='status')?'none':'block';
  try{sessionStorage.setItem('tab',t);}catch(e){}
}
document.querySelectorAll('#nav a').forEach(a=>a.onclick=()=>show(a.dataset.t));
let t0='status';
try{t0=sessionStorage.getItem('tab')||t0;}catch(e){}
if(!document.getElementById('t-'+t0)) t0='status';
show(t0);
</script></body></html>
)=====";


// ---------- Uhr-Designs: Namen und Vorschaubilder (SVG, folgen der Akzentfarbe) ----------
// Namen der Designs, Kategorien und Akzentfarben: lang_web.h (W_ST0.., W_CAT0.., W_AC0..)
#define CAT_COUNT 7
static const uint8_t STYLE_CAT[CLOCK_STYLE_COUNT] = {
  0, 0,                                         // 0 Flip-Karten, 1 Digital + Balken
  1, 1, 1, 3, 1, 3, 1, 1, 1, 1,                 // 2 Abenteuer .. 11 Neonbrecher (5 Neon-Raster, 7 Code-Regen = Technik)
  4, 3, 1, 3, 2,                                // 12 Herz, 13 Sinuskurve, 14 Badminton, 15 Testbild, 16 Dackel
  5, 4, 2, 5, 5,                                // 17 Flugradar, 18 Traumsand, 19 Aquarium, 20 ISS, 21 Sonne und Mond
  6, 6, 6, 6, 6,                                // 22-26 Feiertage
  0,                                            // 27 Grossanzeige (klassisch)
  0                                             // 28 Kalender (klassisch)
};

#define SVG_OPEN "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
static const char SVG_7[] PROGMEM = SVG_OPEN
  "<rect x='8' y='10' width='49' height='42' rx='5' fill='#222'/><rect x='63' y='10' width='49' height='42' rx='5' fill='#222'/>"
  "<g font-family='sans-serif' font-weight='bold' font-size='26' text-anchor='middle'><text x='32' y='42' fill='#eee'>12</text>"
  "<text x='87' y='42' style='fill:var(--acc)'>34</text></g>"
  "<rect x='8' y='30' width='49' height='1.5' fill='#000'/><rect x='63' y='30' width='49' height='1.5' fill='#000'/>"
  "<text x='60' y='64' text-anchor='middle' font-family='sans-serif' font-size='8' fill='#aaa'>Freitag, 23.10.2026</text></svg>";
static const char SVG_8[] PROGMEM = SVG_OPEN
  "<text x='60' y='40' text-anchor='middle' font-family='sans-serif' font-weight='bold' font-size='34' fill='#eee'>12:34</text>"
  "<rect x='10' y='48' width='100' height='5' rx='2.5' fill='#222'/><rect x='10' y='48' width='62' height='5' rx='2.5' style='fill:var(--acc)'/>"
  "<text x='60' y='65' text-anchor='middle' font-family='sans-serif' font-size='8' fill='#aaa'>Freitag, 23.10.2026</text></svg>";

// Themen-Designs (Pixel-Retro): feste Farben, unabhaengig von der Akzentfarbe
static const char SVG_10[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#0a0c26'/>"
  "<circle cx='104' cy='12' r='5' fill='#eeeed6'/><circle cx='106.5' cy='10.5' r='4' fill='#0a0c26'/>"
  "<path d='M0 48 Q30 36 60 46 T120 44 V70 H0Z' fill='#1e3f42'/><rect y='58' width='120' height='12' fill='#22542c'/>"
  "<path d='M14 50l5-14 5 14zM96 50l5-14 5 14zM64 50l4-11 4 11z' fill='#0e2e28'/>"
  "<rect x='14' y='8' width='92' height='26' rx='3' fill='#4a4c60' stroke='#787c96' stroke-width='2'/>"
  "<text x='60' y='28' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#ffcc40'>12:34</text>"
  "<rect x='56' y='48' width='4' height='9' fill='#40b054'/><rect x='56' y='45' width='4' height='3' fill='#f4ccA4'/></svg>";
static const char SVG_11[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#121426'/>"
  "<rect x='74' y='0' width='46' height='70' fill='#0c0c18'/>"
  "<g fill='#e63232'><rect x='76' y='64' width='6' height='6'/><rect x='82' y='64' width='6' height='6'/><rect x='82' y='58' width='6' height='6'/></g>"
  "<g fill='#00dce6'><rect x='88' y='64' width='6' height='6'/><rect x='94' y='64' width='6' height='6'/><rect x='100' y='64' width='6' height='6'/><rect x='106' y='64' width='6' height='6'/></g>"
  "<g fill='#f0dc00'><rect x='100' y='58' width='6' height='6'/><rect x='106' y='58' width='6' height='6'/></g>"
  "<g fill='#aa3cdc'><rect x='94' y='58' width='6' height='6'/></g>"
  "<text x='6' y='24' font-family='monospace' font-weight='bold' font-size='17' fill='#3ce0e8'>12:34</text>"
  "<rect x='6' y='30' width='56' height='3' fill='#2a2e50'/><rect x='6' y='30' width='34' height='3' fill='#f0dc00'/>"
  "<rect x='6' y='42' width='16' height='16' fill='none' stroke='#5a64a0'/><rect x='10' y='48' width='8' height='4' fill='#fa961e'/></svg>";
static const char SVG_13[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#5c94fc'/>"
  "<g fill='#f0be3c' stroke='#96600a' stroke-width='1.5'><rect x='9' y='9' width='16' height='16'/><rect x='28' y='9' width='16' height='16'/>"
  "<rect x='76' y='9' width='16' height='16'/><rect x='95' y='9' width='16' height='16'/></g>"
  "<g font-family='monospace' font-weight='bold' font-size='13' fill='#5a2d00' text-anchor='middle'><text x='17' y='22'>1</text><text x='36' y='22'>2</text>"
  "<text x='84' y='22'>3</text><text x='103' y='22'>4</text></g>"
  "<ellipse cx='30' cy='40' rx='9' ry='4' fill='#f8f8fc'/><ellipse cx='88' cy='36' rx='9' ry='4' fill='#f8f8fc'/>"
  "<rect y='56' width='120' height='14' fill='#be5014'/><path d='M0 62H120M0 68H120' stroke='#6e2c00'/>"
  "<circle cx='60' cy='50' r='6' fill='#3cc88c'/><rect x='62' y='47' width='3' height='4' fill='#fff'/></svg>";
static const char SVG_14[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<g stroke='#00506e' stroke-width='.8'><path d='M12 0V70M24 0V70M36 0V70M48 0V70M60 0V70M72 0V70M84 0V70M96 0V70M108 0V70"
  "M0 11H120M0 22H120M0 33H120M0 44H120M0 55H120'/></g>"
  "<path d='M24 11H48V33' fill='none' stroke='#8ff' stroke-width='1.6'/>"
  "<text x='60' y='42' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='24' fill='#bff' stroke='#00a0d8' stroke-width='.8'>12:34</text>"
  "<rect x='3' y='3' width='114' height='64' fill='none' stroke='#ff9600' stroke-width='1' stroke-dasharray='28 400'/></svg>";
static const char SVG_15[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<g fill='none' stroke='#aab0c4' stroke-width='1'><path d='M12 14l8-4 7 5-2 8-9 2-5-6zM92 48l9-3 6 6-3 8-8 1-6-6z'/><path d='M26 52l4-6 5 3-3 6z'/></g>"
  "<text x='60' y='42' text-anchor='middle' font-family='monospace' font-size='26' fill='none' stroke='#e6eeff' stroke-width='1'>12:34</text>"
  "<path d='M60 56l-3 8 3-2 3 2z' fill='none' stroke='#fff'/><path d='M60 54V44' stroke='#fff' stroke-dasharray='2 3'/></svg>";
static const char SVG_16[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<g font-family='monospace' font-size='7' fill='#0a8a38'><text x='6' y='9'>7 A 3</text><text x='6' y='33'>K 0 X</text><text x='100' y='15'>9 N</text><text x='98' y='60'>Z 4 #</text><text x='8' y='62'>= H</text></g>"
  "<g font-family='monospace' font-size='7' fill='#46ff7a'><text x='7' y='17'>2</text><text x='101' y='23'>E</text><text x='99' y='68'>R</text></g>"
  "<rect x='20' y='14' width='80' height='24' fill='#000' stroke='#00a03c'/>"
  "<text x='60' y='33' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='18' fill='#a8ffc0'>12:34</text>"
  "<rect x='20' y='42' width='80' height='16' fill='#000' stroke='#00a03c'/>"
  "<text x='25' y='51' font-family='monospace' font-size='6' fill='#00eb5f'>&gt; 12C  H63%</text><text x='25' y='56' font-family='monospace' font-size='6' fill='#00eb5f'>&gt; WIND 14_</text></svg>";

static const char SVG_18[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<g><rect x='3' y='4' width='114' height='4' fill='#e62828'/><rect x='3' y='10' width='114' height='4' fill='#fa8c1e'/><rect x='3' y='16' width='114' height='4' fill='#f0dc28'/>"
  "<rect x='3' y='22' width='114' height='4' fill='#32c846'/><rect x='3' y='28' width='114' height='4' fill='#3c6ef0'/></g>"
  "<rect x='45' y='4' width='30' height='28' fill='#000'/>"
  "<text x='60' y='52' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='22' fill='#ffd23c'>12:34</text>"
  "<rect x='72' y='58' width='22' height='3' fill='#c8d2e6'/><rect x='50' y='40' width='3' height='3' fill='#fff'/></svg>";
static const char SVG_19[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#1e6e28'/>"
  "<rect x='20' y='2' width='80' height='20' fill='#0a2c16'/>"
  "<text x='60' y='19' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='18' fill='#fff'>12:34</text>"
  "<rect y='26' width='120' height='16' fill='#1446aa'/><rect x='10' y='30' width='24' height='5' fill='#8c5622'/><rect x='70' y='36' width='24' height='5' fill='#8c5622'/>"
  "<rect y='42' width='120' height='4' fill='#1e6e28'/><rect y='46' width='120' height='16' fill='#32323e'/>"
  "<rect x='14' y='49' width='12' height='5' fill='#e63232'/><rect x='70' y='49' width='12' height='5' fill='#f0d228'/><rect x='40' y='56' width='12' height='5' fill='#28d2e6'/>"
  "<rect x='56' y='62' width='7' height='6' fill='#64eb46'/></svg>";
static const char SVG_20[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<path d='M10 0L40 40M96 0L82 42' stroke='#ff4632' stroke-width='.8'/><path d='M60 60L58 32' stroke='#4682ff'/>"
  "<circle cx='58' cy='30' r='5' fill='#ff961e'/><circle cx='58' cy='30' r='3' fill='#ffe678'/>"
  "<rect x='16' y='14' width='88' height='30' fill='#000' stroke='#4682ff'/>"
  "<text x='60' y='39' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='22' fill='#a0cdff'>12:34</text>"
  "<g fill='#283e82'><rect x='4' y='56' width='8' height='10'/><rect x='14' y='52' width='9' height='14'/><rect x='25' y='57' width='7' height='9'/><rect x='36' y='50' width='9' height='16'/><rect x='48' y='55' width='8' height='11'/>"
  "<rect x='60' y='52' width='9' height='14'/><rect x='72' y='57' width='8' height='9'/><rect x='84' y='51' width='9' height='15'/><rect x='96' y='56' width='8' height='10'/></g>"
  "<rect y='66' width='120' height='4' fill='#5a2c18'/></svg>";
static const char SVG_21[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<rect x='1' y='1' width='118' height='68' fill='none' stroke='#00c8ff'/>"
  "<text x='60' y='19' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='17' fill='#78f0ff'>12:34</text>"
  "<path d='M3 26H117' stroke='#ff3cd2'/>"
  "<g><rect x='5' y='31' width='20' height='4' fill='#00e6ff'/><rect x='28' y='31' width='20' height='4' fill='#00e6ff'/><rect x='51' y='31' width='20' height='4' fill='#00e6ff'/>"
  "<rect x='5' y='37' width='20' height='4' fill='#ff28c8'/><rect x='51' y='37' width='20' height='4' fill='#ff28c8'/><rect x='74' y='37' width='20' height='4' fill='#ff28c8'/>"
  "<rect x='28' y='43' width='20' height='4' fill='#ffe628'/><rect x='74' y='43' width='20' height='4' fill='#ffe628'/><rect x='97' y='43' width='16' height='4' fill='#3cff78'/></g>"
  "<rect x='46' y='62' width='28' height='3' fill='#78f0ff'/><rect x='62' y='54' width='3' height='3' fill='#fff'/></svg>";
static const char SVG_22[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#14061a'/>"
  "<text x='60' y='19' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='17' fill='#ffecf2'>12:34</text>"
  "<circle cx='60' cy='30' r='12' fill='none' stroke='#82204a'/>"
  "<path d='M60 49C46 40 48 26 54 26C58 26 60 29 60 31C60 29 62 26 66 26C72 26 74 40 60 49Z' fill='#eb2850'/>"
  "<path d='M0 60H34L38 56L42 62L46 46L50 66L54 60H70L74 56L78 60H120' fill='none' stroke='#78ffa0' stroke-width='1.2'/>"
  "<rect x='8' y='66' width='70' height='2' fill='#c83c6e'/></svg>";
static const char SVG_23[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#030c10'/>"
  "<g fill='#0e2c34'><rect x='0' y='35' width='120' height='.6'/><rect x='60' y='6' width='.6' height='58'/></g>"
  "<path d='M0 35Q15 8 30 35T60 35T90 35T120 35' fill='none' stroke='#28e6ff' stroke-width='1.4'/>"
  "<path d='M0 35Q8 50 15 35T30 35T45 35T60 35T75 35T90 35T105 35T120 35' fill='none' stroke='#ff3cd2' stroke-width='1'/>"
  "<path d='M0 35Q12 22 24 36T52 36T84 28T120 38' fill='none' stroke='#ffe83c' stroke-width='1.6'/>"
  "<rect x='20' y='25' width='80' height='21' fill='#020a0e'/>"
  "<text x='60' y='43' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='22' fill='#ebfffa'>12:34</text>"
  "<rect x='6' y='58' width='108' height='1' fill='#0e2c34'/><rect x='68' y='54' width='4' height='8' fill='#ff8c28'/></svg>";
static const char SVG_24[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#1c3a4a'/>"
  "<rect y='56' width='120' height='14' fill='#a8703a'/><path d='M0 56H120' stroke='#f0f0e6'/>"
  "<text x='60' y='22' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#fff' stroke='#081420' stroke-width='.6'>12:34</text>"
  "<rect x='59' y='38' width='2' height='20' fill='#c8c8d2'/><rect x='52' y='38' width='16' height='2' fill='#fff'/>"
  "<g fill='#e03838'><circle cx='24' cy='40' r='3' fill='#f0c096'/><rect x='22' y='43' width='5' height='8'/></g><path d='M25 44L33 34' stroke='#ddd'/><circle cx='35' cy='32' r='3' fill='none' stroke='#ddd'/>"
  "<g fill='#3c78eb'><rect x='94' y='43' width='5' height='8'/></g><circle cx='96' cy='40' r='3' fill='#f0c096'/><path d='M95 44L87 34' stroke='#ddd'/><circle cx='85' cy='32' r='3' fill='none' stroke='#ddd'/>"
  "<path d='M38 36Q60 8 82 36' fill='none' stroke='#fff' stroke-dasharray='1 3'/><rect x='58' y='20' width='3' height='3' fill='#ff9628'/>"
  "<path d='M22 51v5M26 51v5M95 51v5M98 51v5' stroke='#eee'/></svg>";
static const char SVG_25[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#4a4a50'/>"
  "<path d='M0 0L120 70M120 0L0 70' stroke='#606068'/>"
  "<circle cx='60' cy='33' r='22' fill='none' stroke='#eee' stroke-width='1.5'/>"
  "<g><rect x='6' y='5' width='15' height='13' fill='#ebebeb'/><rect x='21' y='5' width='15' height='13' fill='#ebeb14'/><rect x='36' y='5' width='15' height='13' fill='#14ebeb'/>"
  "<rect x='51' y='5' width='15' height='13' fill='#14dc1e'/><rect x='66' y='5' width='15' height='13' fill='#eb1eeb'/><rect x='81' y='5' width='15' height='13' fill='#eb1e1e'/><rect x='96' y='5' width='15' height='13' fill='#1e1eeb'/></g>"
  "<rect x='10' y='24' width='100' height='22' fill='#060609' stroke='#fff'/>"
  "<text x='60' y='41' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='17' fill='#f5f5eb'>12:34</text>"
  "<g><rect x='6' y='52' width='13' height='8' fill='#000'/><rect x='19' y='52' width='13' height='8' fill='#242424'/><rect x='32' y='52' width='13' height='8' fill='#484848'/><rect x='45' y='52' width='13' height='8' fill='#6c6c6c'/>"
  "<rect x='58' y='52' width='13' height='8' fill='#909090'/><rect x='71' y='52' width='13' height='8' fill='#b4b4b4'/><rect x='84' y='52' width='13' height='8' fill='#d8d8d8'/><rect x='97' y='52' width='13' height='8' fill='#fff'/></g>"
  "<path d='M60 62L56 68H64Z' fill='#fff'/></svg>";
static const char SVG_26[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#6eb6ff'/><rect y='36' width='120' height='34' fill='#56b046'/>"
  "<text x='60' y='25' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#fff' stroke='#163470' stroke-width='.6'>12:34</text>"
  "<rect x='34' y='47' width='38' height='9' rx='4' fill='#221c1e'/><rect x='38' y='54' width='4' height='6' fill='#221c1e'/><rect x='46' y='54' width='4' height='6' fill='#221c1e'/><rect x='62' y='54' width='4' height='6' fill='#221c1e'/>"
  "<circle cx='78' cy='46' r='6' fill='#221c1e'/><rect x='80' y='46' width='11' height='6' rx='2' fill='#c47028'/><rect x='72' y='44' width='5' height='13' rx='2' fill='#221c1e'/>"
  "<path d='M34 50Q28 44 25 40' stroke='#221c1e' stroke-width='3' fill='none'/><circle cx='14' cy='57' r='4' fill='#e83c3c'/></svg>";
static const char SVG_30[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#000'/>"
  "<circle cx='42' cy='35' r='31' fill='#02140c' stroke='#1a7842'/><circle cx='42' cy='35' r='20' fill='none' stroke='#0c4226'/><circle cx='42' cy='35' r='10' fill='none' stroke='#0c4226'/>"
  "<path d='M42 4V66M11 35H73' stroke='#0c4226'/><path d='M42 35L66 22' stroke='#6eff9f' stroke-width='1.2'/>"
  "<path d='M30 18L36 27L26 25Z' fill='#ffe646'/><path d='M58 44L50 47L53 39Z' fill='#ff8c3c'/><path d='M24 46L33 44L30 52Z' fill='#5ae6ff'/><path d='M42 31v8M38 35h8' stroke='#fff'/>"
  "<text x='98' y='24' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#f0ffec'>14</text>"
  "<text x='98' y='46' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#f0ffec'>37</text>"
  "<path d='M80 52H116' stroke='#1a7842'/><text x='98' y='62' text-anchor='middle' font-family='monospace' font-size='8' fill='#ffbe3c'>DLH4BC</text></svg>";
static const char SVG_31[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#14143e'/>"
  "<circle cx='104' cy='12' r='7' fill='#ffecaa'/><circle cx='107' cy='10' r='6' fill='#14143e'/>"
  "<g fill='#fff4c8'><rect x='14' y='8' width='1.5' height='1.5'/><rect x='40' y='16' width='1.5' height='1.5'/><rect x='70' y='6' width='1.5' height='1.5'/><rect x='90' y='28' width='1.5' height='1.5'/></g>"
  "<text x='60' y='34' fill='#ffeebe' font-size='16' font-family='monospace' text-anchor='middle'>21:45</text>"
  "<ellipse cx='28' cy='60' rx='20' ry='7' fill='#c8cef0'/><rect x='22' y='42' width='10' height='14' fill='#7850c8'/><circle cx='27' cy='38' r='5' fill='#ffcdaa'/><path d='M22 37L32 37L26 24Z' fill='#7850c8'/><path d='M23 40L31 40L27 50Z' fill='#f0f0fa'/>"
  "<g fill='#ffdc6e'><rect x='40' y='44' width='1.5' height='1.5'/><rect x='46' y='50' width='1.5' height='1.5'/><rect x='52' y='56' width='1.5' height='1.5'/><rect x='58' y='61' width='1.5' height='1.5'/><rect x='50' y='46' width='1.5' height='1.5'/></g></svg>";

static const char SVG_33[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#0a3e6e'/>"
  "<text x='60' y='15' fill='#f0fcff' font-size='12' font-family='monospace' text-anchor='middle'>21:45</text>"
  "<rect y='58' width='120' height='12' fill='#d6be82'/><path d='M12 58q-3-12 2-20M30 58q4-10-1-16M96 58q-4-14 1-22' stroke='#28aa5a' stroke-width='2' fill='none'/>"
  "<ellipse cx='42' cy='34' rx='9' ry='5' fill='#ff8c28'/><path d='M33 34l-7-5v10z' fill='#fff0e6'/><ellipse cx='78' cy='44' rx='8' ry='4.5' fill='#3c96ff'/><path d='M86 44l7-5v10z' fill='#145ab8'/>"
  "<circle cx='60' cy='24' r='2' fill='none' stroke='#aadcff'/><circle cx='100' cy='36' r='1.5' fill='none' stroke='#aadcff'/></svg>";

static const char SVG_38[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#06081a'/>"
  "<rect x='4' y='14' width='112' height='48' fill='#16549f'/><path d='M60 14H112V62H78Z' fill='#06123a'/>"
  "<path d='M10 28q10-8 20 0t10 10-8 14-12-4-10-20M54 22q12-6 26 2t14 12-6 14-26-6-8-22' fill='#48964c'/>"
  "<circle cx='52' cy='34' r='9' fill='none' stroke='#6ebefa'/><rect x='50' y='32' width='5' height='5' fill='#fff'/><path d='M20 56q30-40 70-34' stroke='#ffdc78' stroke-dasharray='2 3' fill='none'/>"
  "<text x='6' y='11' fill='#f4f8ff' font-size='9' font-family='monospace'>21:45</text></svg>";
static const char SVG_39[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#0a0e22'/>"
  "<text x='6' y='12' fill='#fff8e6' font-size='11' font-family='monospace'>21:45</text>"
  "<rect x='6' y='16' width='108' height='30' fill='#4682c8'/><rect x='6' y='34' width='108' height='12' fill='#0c102c'/>"
  "<path d='M6 44Q36 4 60 8T114 44' stroke='#ffd646' stroke-width='2' fill='none'/><path d='M6 44Q50 28 80 20T114 40' stroke='#d6e0f0' fill='none'/>"
  "<line x1='88' y1='16' x2='88' y2='46' stroke='#ff7878'/><circle cx='88' cy='42' r='3' fill='#ffd646'/>"
  "<text x='6' y='58' fill='#ffd646' font-size='7' font-family='monospace'>AUF 08:09</text><text x='6' y='66' fill='#fff' font-size='7' font-family='monospace'>UNT 18:21</text>"
  "<circle cx='100' cy='58' r='8' fill='#2c3246'/><path d='M100 50A8 8 0 0 1 100 66A5 8 0 0 0 100 50Z' fill='#ecebd6'/></svg>";

// Feiertage
static const char SVG_40[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#0e1840'/>"
  "<rect y='58' width='120' height='12' fill='#ecf2ff'/><path d='M19 8l-12 20h6l-9 16h7l-8 15h32l-8-15h7l-9-16h6z' fill='#167838'/>"
  "<rect x='16' y='58' width='6' height='5' fill='#6e4222'/><circle cx='19' cy='7' r='2.5' fill='#ffe250'/>"
  "<g fill='#ff4040'><circle cx='14' cy='30' r='1.3'/><circle cx='24' cy='42' r='1.3'/><circle cx='12' cy='52' r='1.3'/></g>"
  "<g fill='#50aaff'><circle cx='22' cy='24' r='1.3'/><circle cx='16' cy='44' r='1.3'/><circle cx='28' cy='54' r='1.3'/></g>"
  "<text x='80' y='22' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#fff8e8'>12:34</text>"
  "<text x='80' y='42' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='14' fill='#fff8e8'>57 <tspan font-size='9'>TAGE</tspan></text>"
  "<g fill='#c81e28'><rect x='62' y='48' width='4' height='9'/><rect x='72' y='48' width='4' height='9'/><rect x='82' y='48' width='4' height='9'/><rect x='92' y='48' width='4' height='9'/></g>"
  "<g fill='#ffd860'><rect x='63' y='44' width='2' height='3'/><rect x='73' y='44' width='2' height='3'/></g></svg>";
static const char SVG_42[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#2a0e4a'/>"
  "<circle cx='16' cy='14' r='10' fill='#faf0c4'/><rect y='58' width='120' height='12' fill='#0a0412'/>"
  "<path d='M10 58l4-30 4 30zM14 36l-8-8M15 34l9-9' stroke='#06020c' stroke-width='2' fill='#06020c'/>"
  "<text x='76' y='22' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#ff9620'>12:34</text>"
  "<ellipse cx='98' cy='54' rx='14' ry='10' fill='#ff8214'/><rect x='97' y='41' width='3' height='4' fill='#466420'/>"
  "<path d='M90 50l3-4 3 4zM100 50l3-4 3 4zM90 56h16l-3 3-2-2-3 3-3-3-2 2z' fill='#ffec6e'/>"
  "<path d='M56 52a7 7 0 0 1 14 0v10l-2-2-2 2-2-2-2 2-2-2-2 2z' fill='#f0f0fa'/><circle cx='60' cy='51' r='1.3'/><circle cx='66' cy='51' r='1.3'/>"
  "<path d='M30 34l4 2 4-2-2 3h-4z' fill='#000'/></svg>";
static const char SVG_43[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#96d0fc'/>"
  "<circle cx='12' cy='12' r='7' fill='#ffe65a'/><ellipse cx='60' cy='76' rx='80' ry='24' fill='#6ec85a'/>"
  "<g font-family='monospace' font-weight='bold' font-size='20' text-anchor='middle'><text x='60' y='24'><tspan fill='#f05a96'>1</tspan><tspan fill='#f5aa14'>2</tspan><tspan fill='#e64678'>:</tspan><tspan fill='#28aa5a'>3</tspan><tspan fill='#8c5aeb'>4</tspan></text></g>"
  "<ellipse cx='84' cy='56' rx='9' ry='6' fill='#c4a078'/><circle cx='93' cy='49' r='5' fill='#c4a078'/>"
  "<rect x='91' y='34' width='3' height='12' rx='1.5' fill='#c4a078'/><rect x='95' y='36' width='3' height='11' rx='1.5' fill='#c4a078'/>"
  "<ellipse cx='30' cy='58' rx='4' ry='5' fill='#ff788c'/><ellipse cx='42' cy='60' rx='4' ry='5' fill='#78aaff'/><ellipse cx='108' cy='60' rx='4' ry='5' fill='#ffd246'/>"
  "<path d='M26 58h8M38 60h8' stroke='#fff' stroke-width='1'/></svg>";
static const char SVG_44[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#aa3264'/>"
  "<path d='M0 2a2 2 0 0 1 4 0a2 2 0 0 1 4 0q0 3-4 6q-4-3-4-6z' fill='#ff5a78' transform='translate(8 30) scale(1.4)'/>"
  "<path d='M0 2a2 2 0 0 1 4 0a2 2 0 0 1 4 0q0 3-4 6q-4-3-4-6z' fill='#ffd2e2' transform='translate(100 8) scale(1.2)'/>"
  "<path d='M0 2a2 2 0 0 1 4 0a2 2 0 0 1 4 0q0 3-4 6q-4-3-4-6z' fill='#ff8cb0' transform='translate(30 52) scale(1)'/>"
  "<text x='60' y='24' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#fff'>12:34</text>"
  "<text x='60' y='42' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='12' fill='#ffecf4'>109 TAGE</text>"
  "<rect x='86' y='50' width='26' height='15' fill='#fff4e8'/><path d='M86 50l13 8 13-8' fill='none' stroke='#dcc8be'/>"
  "<path d='M0 2a2 2 0 0 1 4 0a2 2 0 0 1 4 0q0 3-4 6q-4-3-4-6z' fill='#dc1e3c' transform='translate(96 54) scale(.8)'/></svg>";
static const char SVG_45[] PROGMEM =
  "<svg viewBox='0 0 120 70' width='100%'><rect width='120' height='70' rx='6' fill='#060a26'/>"
  "<g stroke-width='1.2'><path d='M22 20l-8-6M22 20l8-6M22 20l-10 2M22 20l10 2M22 20l-6 8M22 20l6 8M22 20v-10' stroke='#ff5064'/>"
  "<path d='M96 16l-7-5M96 16l7-5M96 16l-9 2M96 16l9 2M96 16l-5 7M96 16l5 7M96 16v-9' stroke='#5ae6ff'/></g>"
  "<text x='60' y='34' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='20' fill='#fff6dc'>12:34</text>"
  "<text x='60' y='46' text-anchor='middle' font-family='monospace' font-weight='bold' font-size='9' fill='#ffe080'>BIS 2027</text>"
  "<path d='M0 70V58h8v-6h8v8h8v-12h8v10h8v-6h8v4h8v-14h8v12h8v-8h8v6h8v-10h8v8h8v-4h8v12z' fill='#0c0c18' transform='translate(0 9)'/>"
  "<g fill='#ffd26e' transform='translate(0 6)'><rect x='19' y='60' width='1.5' height='1.5'/><rect x='51' y='62' width='1.5' height='1.5'/><rect x='67' y='56' width='1.5' height='1.5'/><rect x='99' y='62' width='1.5' height='1.5'/></g></svg>";
static const char SVG_BIG[] PROGMEM = SVG_OPEN
  "<text x='60' y='44' text-anchor='middle' font-family='sans-serif' font-weight='bold' font-size='46' style='fill:var(--acc)'>12:34</text>"
  "<rect x='6' y='50' width='108' height='3' rx='1.5' fill='#333'/><rect x='6' y='50' width='60' height='3' rx='1.5' style='fill:var(--acc)'/>"
  "<text x='8' y='70' font-family='sans-serif' font-weight='bold' font-size='13' fill='#eee'>7&#176;</text>"
  "<text x='112' y='68' text-anchor='end' font-family='sans-serif' font-size='9' fill='#aaa'>Mo 09.11.</text></svg>";


static const char SVG_CAL[] PROGMEM = SVG_OPEN
  "<text x='6' y='18' font-family='sans-serif' font-weight='bold' font-size='15' style='fill:var(--acc)'>12:34</text>"
  "<text x='114' y='16' text-anchor='end' font-family='sans-serif' font-size='8' fill='#ccc'>Di 10. Nov</text>"
  "<rect x='4' y='22' width='112' height='0.8' fill='#444'/>"
  "<g font-family='sans-serif' font-size='6' text-anchor='middle'>"
  "<rect x='7' y='45' width='60' height='7' fill='#1f3a6e'/><rect x='44' y='35' width='8' height='8' rx='2' style='fill:var(--acc)'/>"
  "<text x='12' y='33' fill='#ddd'>1</text><text x='21' y='33' fill='#ddd'>2</text><text x='30' y='33' fill='#ddd'>3</text><text x='39' y='33' fill='#ddd'>4</text><text x='48' y='33' fill='#ddd'>5</text><text x='57' y='33' fill='#888'>6</text><text x='66' y='33' fill='#e07070'>7</text>"
  "<text x='12' y='41' fill='#ddd'>8</text><text x='21' y='41' fill='#ff6060'>9</text><text x='30' y='41' fill='#ddd'>10</text><text x='39' y='41' fill='#ddd'>11</text><text x='48' y='41' fill='#000'>12</text><text x='57' y='41' fill='#888'>13</text><text x='66' y='41' fill='#e07070'>14</text>"
  "<text x='12' y='50' fill='#ddd'>15</text><text x='21' y='50' fill='#ddd'>16</text><text x='30' y='50' fill='#ddd'>17</text><text x='39' y='50' fill='#ddd'>18</text><text x='48' y='50' fill='#ddd'>19</text><text x='57' y='50' fill='#888'>20</text><text x='66' y='50' fill='#e07070'>21</text>"
  "<text x='12' y='59' fill='#ddd'>22</text><text x='21' y='59' fill='#ddd'>23</text><text x='30' y='59' fill='#ddd'>24</text><text x='39' y='59' fill='#ddd'>25</text><text x='48' y='59' fill='#ddd'>26</text><text x='57' y='59' fill='#888'>27</text><text x='66' y='59' fill='#e07070'>28</text>"
  "<circle cx='30' cy='61' r='1' fill='#f0a030'/></g>"
  "<rect x='74' y='26' width='0.8' height='40' fill='#444'/>"
  "<text x='78' y='34' font-family='sans-serif' font-size='5' fill='#999'>FEIERTAG</text>"
  "<text x='78' y='42' font-family='sans-serif' font-weight='bold' font-size='7' style='fill:var(--acc)'>Advent</text>"
  "<text x='78' y='53' font-family='sans-serif' font-size='5' fill='#999'>FERIEN</text>"
  "<text x='78' y='61' font-family='sans-serif' font-weight='bold' font-size='7' fill='#79c0ff'>Weihn.</text></svg>";

static const char* const STYLE_SVG[CLOCK_STYLE_COUNT] = {SVG_7, SVG_8,
  SVG_10, SVG_11, SVG_13, SVG_14, SVG_15, SVG_16, SVG_18, SVG_19, SVG_20, SVG_21, SVG_22, SVG_23, SVG_24, SVG_25, SVG_26,
  SVG_30, SVG_31, SVG_33, SVG_38, SVG_39, SVG_40, SVG_42, SVG_43, SVG_44, SVG_45, SVG_BIG, SVG_CAL};

static String autoInfo() {                     // Ergebnis ist HTML (Design-Namen mit Entities)
  const uint32_t now = millis();
  char b[96];
  if ((int32_t)(now - gAutoHold) < 0) {
    snprintf(b, sizeof(b), TR(W_AUTO_PAUSE), (unsigned long)((gAutoHold - now) / 1000UL));
    return String(b);
  }
  const uint32_t iv = gSet.autoSec * 1000UL, el = now - gStyleSince;
  String h = TR(W_AUTO_ON);
  const uint64_t hm = holidayMask() & ~gSet.autoMask;
  bool first = true;
  for (int i = 0; i < CLOCK_STYLE_COUNT; i++)
    if (hm & (1ULL << i)) { h += first ? " + " : ", "; first = false; h += TR(W_ST0 + i); }
  snprintf(b, sizeof(b), TR(W_AUTO_NEXT), (unsigned long)((el < iv ? iv - el : 0) / 1000UL));
  return h + b;
}

static void handleRoot() {
  if (!authOk()) return;
  // Seite wird in Stuecken gesendet (chunked): kein grosser RAM-Block noetig, die Seite kann nicht mehr abgeschnitten werden
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html; charset=utf-8", "");
  String p;
  p.reserve(4096);
  auto fl = [&]() { if (p.length() > 1200) { server.sendContent(p); p = ""; } };
  auto T  = [&](uint16_t id) { p += TR(id); };                       // Text in der eingestellten Sprache anhaengen
  auto sel = [&](bool on) { p += on ? F(" selected") : F(""); };
  auto chk = [&](bool on) { p += on ? F(" checked") : F(""); };
  p += F("<!doctype html><html lang="); p += LANG_CODE[LANG_IDX]; p += '>';
  p += FPSTR(PAGE_HEAD);

  // ---- Navigation (Kategorien) ----
  p += F("<div class=app><nav id=nav><a data-t=status>"); T(W_STATUS);
  p += F("</a><a data-t=display>");   T(W_DISPLAY);
  p += F("</a><a data-t=bright>");    T(W_BRIGHT);
  p += F("</a><a data-t=ticker>");    T(W_TICKER);
  p += F("</a><a data-t=sound>");     T(W_SOUND);
  p += F("</a><a data-t=net>");       T(W_WIFI);
  p += F("</a><a data-t=time>");      T(W_TIMEWX);
  p += F("</a><a data-t=cal>");       T(W_TAB_CAL);
  p += F("</a><a data-t=sys>");       T(W_SYSTEM);
  p += F("</a></nav><main><h1>");     T(W_TITLE); p += F("</h1>");
  if (server.hasArg("saved")) { p += F("<div class=ok>"); T(W_SAVED); p += F("</div>"); }
  if (gSet.webPw[0] == 0) { p += F("<div class=warn>"); T(W_NOPW); p += F("</div>"); }

  // Unsichtbarer Standard-Button: Enter in einem Feld soll "Speichern" ausloesen, nicht Standby/Reset
  p += F("<form method=post action=/save><button type=submit class=hid tabindex=-1 aria-hidden=true></button>");

  // ================= Status =================
  auto rowh = [&](uint16_t k, const String& html) {      // Wert ist schon HTML
    p += F("<tr><td>"); T(k); p += F("</td><td>"); p += html; p += F("</td></tr>");
  };
  auto row = [&](uint16_t k, const String& v) { rowh(k, esc(v)); };
  char fb[160];
  fl();
  p += F("<section class=tab id=t-status><h2>"); T(W_STATUS); p += F("</h2><table>");
  const bool wf = (WiFi.status() == WL_CONNECTED);
  if (wf) row(W_WIFI, String(gSet.ssid) + "  (" + String(WiFi.RSSI()) + " dBm)"); else rowh(W_WIFI, TR(W_NOT_CONN));
  row(W_R_IP, wf ? WiFi.localIP().toString() : String("-"));
  if (apActive) row(W_R_AP, String(AP_SSID) + "  " + WiFi.softAPIP().toString());
  if (timeValid()) {
    time_t n = time(nullptr); struct tm t; localtime_r(&n, &t);
    char tb[16], db[16];
    strftime(tb, sizeof(tb), "%H:%M:%S", &t);
    langDateY(db, sizeof(db), t.tm_mday, t.tm_mon + 1, t.tm_year + 1900);
    rowh(W_R_TIME, String(db) + " " + tb + (gTimeManual ? TR(W_MANUAL_SET) : ""));
  } else rowh(W_R_TIME, TR(gSet.ntpOn ? W_NOT_SYNC : W_NOT_SETT));
  if (gSet.ntpOn) row(W_R_TSRC, String("NTP (") + gSet.ntp + ")"); else rowh(W_R_TSRC, TR(W_ONLY_MAN));
  Weather w; bool hv = getWeather(w);
  if (hv) {
    snprintf(fb, sizeof(fb), TR(W_WX_FMT), (double)w.temp, (unsigned long)((millis() - w.fetchedMs) / 60000UL));
    rowh(W_R_WX, fb);
  } else rowh(W_R_WX, TR(W_NO_DATA));
  rowh(W_R_DESIGN, String(TR(W_ST0 + (gStyle < CLOCK_STYLE_COUNT ? gStyle : 0))) +
                   (nyeNow() ? String(TR(W_NYE_S)) : (nightTv() ? String(TR(W_NIGHT_S)) : (autoActive() ? autoInfo() : String("")))) +
                   ", " + TR(W_AC0 + (gSet.accent < ACCENT_COUNT ? gSet.accent : 0)));
  if (gSet.dimOn) {
    snprintf(fb, sizeof(fb), TR(W_DIM_FMT), (unsigned)gSet.dimLevel, hhmm(gSet.dimStart).c_str(), hhmm(gSet.dimEnd).c_str());
    rowh(W_R_DIMSCH, String(TR(gDimActive ? W_DIM_ACT : W_DIM_WAIT)) + fb + (gSet.dimTv ? TR(W_WITH_TV) : ""));
  } else rowh(W_R_DIMSCH, TR(W_OFF));
  rowh(W_R_DIM, TR(HW_DIM ? W_DIM_HW : W_DIM_SW));
  rowh(W_R_DISP, TR(standby ? W_STANDBY_S : W_ON));
#if TOUCH_XPT2046
  {
    const bool on = boardTouchRaw();
    String v = String("XPT2046") + TR(W_T_LEVEL) + "Z=" + xpt::lastZ +
               TR(on ? W_TOUCHED : W_FREE) + TR(W_DETECTED) + gTouchCount + "x";
    if (gTouchCount) { snprintf(fb, sizeof(fb), TR(W_LAST_AGO), (unsigned long)((millis() - gTouchLastMs) / 1000UL)); v += fb; }
    rowh(W_R_TOUCH, v);
  }
#elif PIN_TOUCH >= 0
  {
    const bool hi = digitalRead(PIN_TOUCH) == HIGH;
    String v = String("GPIO ") + PIN_TOUCH + TR(W_T_LEVEL) + (hi ? "HIGH" : "LOW") +
               TR(hi == (TOUCH_ACTIVE_HIGH != 0) ? W_TOUCHED : W_FREE) + TR(W_DETECTED) + gTouchCount + "x";
    if (gTouchCount) { snprintf(fb, sizeof(fb), TR(W_LAST_AGO), (unsigned long)((millis() - gTouchLastMs) / 1000UL)); v += fb; }
    rowh(W_R_TOUCH, v);
  }
#else
  rowh(W_R_TOUCH, TR(W_TOUCH_OFF));
#endif
  if (!bz::present()) rowh(W_R_BUZZ, TR(W_BZ_NONE));
  else if (gAlarmRinging) rowh(W_R_ALARM, TR(W_RINGING));
  else if (gSet.alOn) {
    String d;
    for (int i = 0; i < 7; i++) if (gSet.alDays & (1 << i)) { if (d.length()) d += ' '; d += WEEKDAY2[(i + 1) % 7]; }
    rowh(W_R_ALARM, hhmm(gSet.alTime) + (d.length() ? String("  ") + d : String(TR(W_NO_DAY))));
  } else rowh(W_R_ALARM, TR(W_OFF));
  rowh(W_R_LANG, LANG_NAME[LANG_IDX]);
  row(W_R_HEAP, String(ESP.getFreeHeap()) + " Bytes");
  row(W_R_BOARD, boardName());
  row(W_R_PANEL, boardPanelInfo());
#if BOARD_CYD
  rowh(W_R_GAMES, TR(dual::games() ? W_G_YES : W_G_NO));
  {
    nvs_stats_t st;
    if (nvs_get_stats(nullptr, &st) == ESP_OK) {
      snprintf(fb, sizeof(fb), TR(W_NVS_FMT), (unsigned)st.used_entries, (unsigned)st.total_entries);
      rowh(W_R_NVS, String(fb) + (gSetRestored ? TR(W_NVS_RESTORED) : ""));
    }
  }
#endif
  row(W_R_FW, String(FW_VERSION) + "  (" + TR(W_BUILT) + " " + __DATE__ + " " + __TIME__ + ")");
  p += F("</table>");
  if (gAlarmRinging) { p += F("<button type=submit class=red formaction=/alarmoff formmethod=post formnovalidate>"); T(W_AL_STOP); p += F("</button>"); }
  p += F("</section>");

  // ================= Anzeige =================
  fl();
  p += F("<section class=tab id=t-display><h2>"); T(W_R_DESIGN); p += F("</h2><div class=chips id=cf><a class=on data-c=-1>"); T(W_ALL); p += F("</a>");
  for (int k = 0; k < CAT_COUNT; k++) { p += F("<a data-c="); p += String(k); p += F(">"); T(W_CAT0 + k); p += F("</a>"); }
  p += F("</div><div class=cards id=cards>");
  for (int i = 0; i < CLOCK_STYLE_COUNT; i++) {
    fl();
    p += F("<label class=card data-c="); p += String(STYLE_CAT[i]); p += F("><input type=radio name=cs value=");
    p += String(i);
    p += (gSet.clockStyle == i) ? F(" checked>") : F(">");
    p += FPSTR(STYLE_SVG[i]);
    T(W_ST0 + i);
    p += F("</label>");
  }
  p += F("</div><h2>"); T(W_H_ACCENT); p += F("</h2><div>");
  for (int i = 0; i < ACCENT_COUNT; i++) {
    char hx[8];
    snprintf(hx, sizeof(hx), "#%02x%02x%02x", ACCENT_RGB[i][0], ACCENT_RGB[i][1], ACCENT_RGB[i][2]);
    p += F("<label class=sw title=\""); T(W_AC0 + i); p += F("\" style=\"background:"); p += hx;
    p += F("\"><input type=radio name=acc value="); p += String(i);
    p += (gSet.accent == i) ? F(" checked></label>") : F("></label>");
  }
  p += F("</div><small>"); T(W_LOOK_HINT); p += F("</small><script>const accHex=[");
  for (int i = 0; i < ACCENT_COUNT; i++) {
    char hx[12];
    snprintf(hx, sizeof(hx), "%s\"#%02x%02x%02x\"", i ? "," : "", ACCENT_RGB[i][0], ACCENT_RGB[i][1], ACCENT_RGB[i][2]);
    p += hx;
  }
  p += F("];</script>");

  { // Automatischer Wechsel
    uint32_t sec = gSet.autoSec, unit = 1, val = sec;
    if (sec % 3600 == 0) { unit = 3600; val = sec / 3600; }
    else if (sec % 60 == 0) { unit = 60; val = sec / 60; }
    p += F("<h2>"); T(W_H_AUTO); p += F("</h2><label><input type=checkbox name=auto value=1"); chk(gSet.autoOn);
    p += F(">"); T(W_AUTO_CB); p += F("</label><label>"); T(W_AUTO_EVERY);
    p += F("</label><div class=row><input type=number name=aint min=1 max=86400 style='width:6em' value="); p += String(val);
    p += F("><select name=aunit><option value=1"); sel(unit == 1); p += '>'; T(W_SECONDS);
    p += F("</option><option value=60"); sel(unit == 60); p += '>'; T(W_MINUTES);
    p += F("</option><option value=3600"); sel(unit == 3600); p += '>'; T(W_HOURS);
    p += F("</option></select></div><label><input type=checkbox name=arnd value=1"); chk(gSet.autoRnd);
    p += F(">"); T(W_RANDOM); p += F("</label><label>"); T(W_USE_THESE); p += F("</label>");
    for (int k = 0; k < CAT_COUNT; k++) {
      p += F("<label class=cg><input type=checkbox class=cgb data-c="); p += String(k); p += F("> "); T(W_CAT0 + k); p += F("</label>");
      p += F("<div class=cards style='grid-template-columns:1fr 1fr 1fr'>");
      for (int i = 0; i < CLOCK_STYLE_COUNT; i++) {
        fl();
        if (STYLE_CAT[i] != k) continue;
        p += F("<label style='font-weight:normal'><input type=checkbox class=am data-c="); p += String(k); p += F(" name=am"); p += String(i); p += F(" value=1");
        chk((gSet.autoMask >> i) & 1);
        p += F("> "); T(W_ST0 + i); p += F("</label>");
      }
      p += F("</div>");
    }
    p += F("<p><a href='#' onclick=\"document.querySelectorAll('.am').forEach(c=>c.checked=true);grpSync();return false\">"); T(W_ALL_L);
    p += F("</a> &middot; <a href='#' onclick=\"document.querySelectorAll('.am').forEach(c=>c.checked=false);grpSync();return false\">"); T(W_NONE_L);
    p += F("</a></p>"
           "<script>function grpSync(){document.querySelectorAll('.cgb').forEach(g=>{const m=[...document.querySelectorAll('.am[data-c=\"'+g.dataset.c+'\"]')];const n=m.filter(x=>x.checked).length;g.checked=n===m.length;g.indeterminate=n>0&&n<m.length;});}"
           "document.querySelectorAll('.cgb').forEach(g=>g.onchange=()=>{document.querySelectorAll('.am[data-c=\"'+g.dataset.c+'\"]').forEach(x=>x.checked=g.checked);grpSync();});"
           "document.querySelectorAll('.am').forEach(x=>x.onchange=grpSync);grpSync();"
           "document.querySelectorAll('#cf a').forEach(a=>a.onclick=()=>{document.querySelectorAll('#cf a').forEach(z=>z.classList.toggle('on',z===a));const c=a.dataset.c;document.querySelectorAll('#cards .card').forEach(k=>k.style.display=(c==='-1'||k.dataset.c===c)?'':'none');});</script><small>");
    T(W_AUTO_HINT); p += F("</small>");
  }

  // Extras: Feiertage, Silvester-Automatik, Weihnachtsschlitten, UFO, Aquarium
  fl();
  p += F("<h2>"); T(W_H_EXTRAS); p += F("</h2><label><input type=checkbox name=holauto value=1"); chk(gSet.holAuto);
  p += F(">"); T(W_HOL_CB); p += F("</label><small>"); T(W_HOL_HINT);
  p += F("</small><label><input type=checkbox name=nyeauto value=1"); chk(gSet.nyeAuto);
  p += F(">"); T(W_NYE_CB); p += F("</label><label>"); T(W_ISS_SHOWS); p += F("</label><select name=sled>");
  for (int i = 0; i < 3; i++) { p += F("<option value="); p += String(i); sel(gSet.sleigh == i); p += '>'; T(W_SL0 + i); p += F("</option>"); }
  p += F("</select><label><input type=checkbox name=ufo value=1"); chk(gSet.ufoOn);
  p += F(">"); T(W_UFO_CB); p += F("</label><button type=submit class=sec formaction=/ufo formmethod=post formnovalidate>"); T(W_UFO_BTN);
  p += F("</button><small>"); T(W_UFO_HINT); p += F("</small><label>"); T(W_AQUA);
  p += F("</label><button type=submit class=sec formaction=/feed formmethod=post formnovalidate>"); T(W_FEED);
  p += F("</button><button type=submit class=sec formaction=/visit formmethod=post formnovalidate>"); T(W_VISIT);
  p += F("</button><small>"); T(W_AQUA_HINT); p += F("</small>");

  p += F("<h2>"); T(W_H_LOOK); p += F("</h2><label>"); T(W_R_LANG);
  if (gLang != L_EN) p += F(" (Language)");
  p += F("</label><select name=lang>");
  for (int i = 0; i < LANG_COUNT; i++) { p += F("<option value="); p += String(i); sel(gSet.lang == i); p += '>'; p += LANG_NAME[i]; p += F("</option>"); }
  p += F("</select><small>"); T(W_LANG_HINT);
  p += F("</small><label><input type=checkbox name=fsm value=1"); chk(gSet.fine & 1);
  p += F(">"); T(W_FINE_SM); p += F("</label><label><input type=checkbox name=ftx value=1"); chk(gSet.fine & 2);
  p += F(">"); T(W_FINE_TX); p += F("</label><small>"); T(W_FINE_HINT);
  p += F("</small><label><input type=checkbox name=sec value=1"); chk(gSet.seconds);
  p += F(">"); T(W_SHOW_SEC); p += F("</label><label>"); T(W_ORIENT); p += F("</label><select name=rot><option value=1"); sel(gSet.rotation == 1);
  p += F(">"); T(W_NORMAL); p += F("</option><option value=3"); sel(gSet.rotation == 3);
  p += F(">"); T(W_ROT180); p += F("</option></select></section>");

  // ================= Helligkeit =================
  fl();
  p += F("<section class=tab id=t-bright><h2>"); T(W_BRIGHT); p += F("</h2><label>"); T(W_BRIGHT_LBL); p += F("<span id=bv>");
  p += String(gSet.bright);
  p += F("</span> %</label><input id=br name=b type=range min=5 max=100 value=");
  p += String(gSet.bright);
  p += F(">");
  if (!HW_DIM) { p += F("<small>"); T(W_SWDIM_HINT); p += F("</small>"); }
  p += F("<h2>"); T(W_H_ONOFF); p += F("</h2><button type=submit formaction=/standby formmethod=post formnovalidate name=v value=");
  p += standby ? F("0>") : F("1>"); T(standby ? W_DISP_ON : W_DISP_OFF);
  p += F("</button><h2>"); T(W_R_DIMSCH); p += F("</h2><label><input type=checkbox name=dim value=1"); chk(gSet.dimOn);
  p += F(">"); T(W_DIM_CB); p += F("</label><label>"); T(W_DIM_FROM); p += F("</label><input type=time name=dims value=\"");
  p += hhmm(gSet.dimStart);
  p += F("\"><label>"); T(W_DIM_BACK); p += F("</label><input type=time name=dime value=\"");
  p += hhmm(gSet.dimEnd);
  p += F("\"><label>"); T(W_DIM_LEVEL); p += F("</label><input name=diml type=number min=5 max=100 value=");
  p += String(gSet.dimLevel);
  p += F("><label><input type=checkbox name=dimtv value=1"); chk(gSet.dimTv);
  p += F(">"); T(W_DIMTV_CB); p += F("</label><small>"); T(W_DIM_HINT); p += F("</small>");
#if PIN_LED_R >= 0
  {                                                     // RGB-LED des CYD (led.h)
    p += F("<h2>"); T(W_H_LED); p += F("</h2><label>"); T(W_LED_MODE); p += F("</label><select name=ledm id=ledm>");
    for (int i = 0; i < 7; i++) {
      p += F("<option value="); p += String(i); if (gSet.ledMode == i) p += F(" selected"); p += '>'; T(W_LM0 + i); p += F("</option>");
    }
    char hx[8];
    snprintf(hx, sizeof(hx), "#%06lx", (unsigned long)(gSet.ledCol & 0xFFFFFF));
    p += F("</select><label>"); T(W_LED_COL); p += F("</label><input type=color name=ledc id=ledc style='height:2.6em' value=\"");
    p += hx;
    p += F("\"><label>"); T(W_LED_BRI); p += F("<span id=lbv>"); p += String(gSet.ledBri);
    p += F("</span> %</label><input type=range name=ledb id=ledb min=1 max=100 value="); p += String(gSet.ledBri);
    p += F("><label>"); T(W_LED_TIME); p += F("</label><select name=ledt>");
    for (int i = 0; i < 3; i++) {
      p += F("<option value="); p += String(i); if (gSet.ledTime == i) p += F(" selected"); p += '>'; T(W_LT0 + i); p += F("</option>");
    }
    p += F("</select><label>"); T(W_LED_HINTS); p += F("</label>");
    for (int i = 0; i < 4; i++) {
      p += F("<label><input type=checkbox name=lh"); p += String(i); p += F(" value=1"); chk(gSet.ledHint & (1 << i)); p += '>'; T(W_LH0 + i); p += F("</label>");
    }
    p += F("<small>"); T(W_LED_NOTE); p += F("</small><script>(function(){const g=i=>document.getElementById(i),m=g('ledm'),c=g('ledc'),b=g('ledb');let t;"
           "function go(){g('lbv').textContent=b.value;clearTimeout(t);t=setTimeout(()=>fetch('/ledprev',{method:'POST',"
           "headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'m='+m.value+'&c='+c.value.slice(1)+'&b='+b.value}),120);}"
           "m.onchange=go;c.oninput=go;b.oninput=go;})();</script>");
  }
#endif
  p += F("</section>");

  // ================= Laufschrift =================
  fl();
  p += F("<section class=tab id=t-ticker><h2>"); T(W_TICKER); p += F("</h2><label><input type=checkbox name=tkon value=1"); chk(gSet.tickOn);
  p += F(">"); T(W_TK_ON); p += F("</label><label>"); T(W_TK_TEXT); p += F("</label><input name=tk maxlength=160 value=\"");
  p += esc(gSet.tick);
  p += F("\"><div style='margin:.4em 0'>");
  static const char* const SC[] = {"&auml;","&ouml;","&uuml;","&Auml;","&Ouml;","&Uuml;","&szlig;","&euro;","&deg;","&hearts;","&rarr;","&larr;","&uarr;","&darr;","&bull;","&plusmn;","&eacute;","&egrave;"};
  for (unsigned i = 0; i < sizeof(SC) / sizeof(SC[0]); i++) {
    p += F("<button type=button class=sm onclick=\"tkIns(this.textContent)\">"); p += SC[i]; p += F("</button> ");
  }
  p += F("</div><label>"); T(W_TK_FLOW); p += F("</label><select name=tkmode><option value=0"); sel(!gSet.tickLoop);
  p += F(">"); T(W_TK_ONCE); p += F("</option><option value=1"); sel(gSet.tickLoop);
  p += F(">"); T(W_TK_LOOP); p += F("</option></select><label>"); T(W_TK_PAUSE); p += F("</label><input type=number name=tkpause min=0 max=3600 value=");
  p += String(gSet.tickPause);
  p += F("><label>"); T(W_TK_POS); p += F("</label><select name=tkpos>");
  for (int i = 0; i < 3; i++) { p += F("<option value="); p += String(i); sel(gSet.tickPos == i); p += '>'; T(W_TOP + i); p += F("</option>"); }
  p += F("</select><label>"); T(W_TK_SIZE); p += F("</label><select name=tkbig><option value=0"); sel(!gSet.tickBig);
  p += F(">"); T(W_MEDIUM); p += F("</option><option value=1"); sel(gSet.tickBig);
  p += F(">"); T(W_LARGE); p += F("</option></select><label>"); T(W_COLOR); p += F("</label><select name=tkcol>");
  for (int i = 0; i <= ACCENT_COUNT; i++) {
    p += F("<option value="); p += String(i); sel(gSet.tickColor == i); p += '>';
    T(i < ACCENT_COUNT ? W_AC0 + i : W_WHITE); p += F("</option>");
  }
  p += F("</select><label>"); T(W_SPEED); p += F("<span id=tsv>");
  p += String(gSet.tickSpeed);
  p += F("</span></label><input type=range name=tkspd min=1 max=10 value=");
  p += String(gSet.tickSpeed);
  p += F(" oninput=\"document.getElementById('tsv').textContent=this.value\"><label><input type=checkbox name=tkbg value=1"); chk(gSet.tickBg);
  p += F(">"); T(W_TK_BG); p += F("</label><p><button type=button id=tkplay onclick=\"tkPlay()\">"); T(W_TK_PLAY);
  p += F("</button></p><small>"); T(W_TK_HINT); p += F("</small></section>");

  // ================= Summer & Wecker =================
  fl();
#if SND_RICH
  // Lautsprecher (CYD): Lautstaerke, Stundengong, Effekte, Weckton - jeweils mit Anhoeren-Knopf
  auto play = [&](const char* k, const char* n) {        // Knopf "anhoeren"; n = Zahl oder JS-Ausdruck
    p += F("<button type=button class=sec style='width:auto;padding:.35em .8em;margin:.2em 0 .2em .4em' onclick=\"snd('");
    p += k; p += F("',"); p += n; p += F(")\">&#9654;</button>");
  };
  auto opts = [&](const char* name, uint16_t first, int count, int cur) {
    p += F("<div style='display:flex;align-items:center'><select name="); p += name; p += F(" id="); p += name; p += F(" style='flex:1'>");
    for (int i = 0; i < count; i++) { p += F("<option value="); p += String(i); sel(cur == i); p += '>'; T(first + i); p += F("</option>"); }
    p += F("</select>");
  };
  p += F("<section class=tab id=t-sound><h2>"); T(W_R_SPK); p += F("</h2><label>"); T(W_SND_VOL); p += F(" <span id=svv>");
  p += String(gSet.sndVol);
  p += F("</span> %</label><input id=svol name=svol type=range min=5 max=100 value="); p += String(gSet.sndVol);
  p += F(" oninput=\"svv.textContent=this.value\"><small>"); T(W_SND_HINT); p += F("</small>");
  p += F("<label><input type=checkbox name=bzhr value=1"); chk(gSet.bzHour);
  p += F(">"); T(W_HR_ON); p += F("</label>");
  opts("hrtone", W_HRT0, SND_HR_COUNT, gSet.hrTone); play("h", "hrtone.value"); p += F("</div>");
  p += F("<label><input type=checkbox name=bzq value=1"); chk(gSet.bzQuiet);
  p += F(">"); T(W_SND_QUIET); p += F("</label>");
#if HAS_TOUCH
  p += F("<div style='display:flex;align-items:center'><label style='flex:1'><input type=checkbox name=bztc value=1"); chk(gSet.bzTouch);
  p += F(">"); T(W_BZ_TOUCH); p += F("</label>"); play("c", "0"); p += F("</div>");
#endif
  p += F("<h2>"); T(W_H_FX); p += F("</h2>");
  auto fxRow = [&](uint8_t bit, uint16_t txt, const char* n) {
    p += F("<div style='display:flex;align-items:center'><label style='flex:1'><input type=checkbox name=sfx"); p += String(bit);
    p += F(" value=1"); chk(gSet.sndFx & (1 << bit)); p += '>'; T(txt); p += F("</label>");
    if (n) play("f", n);
    p += F("</div>");
  };
  fxRow(0, W_FX_POP, nullptr);
  opts("fxpop", W_FXN0, FX_POP_COUNT, 0); play("f", "fxpop.value"); p += F("</div>");
  { char b[8]; snprintf(b, sizeof(b), "%d", (int)FX_NEWYEAR); fxRow(1, W_FX_NYE, b); }
  { char b[8]; snprintf(b, sizeof(b), "%d", (int)FX_UFO); fxRow(2, W_FX_UFO, b); }
  { char b[8]; snprintf(b, sizeof(b), "%d", (int)FX_STYLE); fxRow(3, W_FX_STYLE, b); }
  fxRow(4, W_FX_WX, nullptr);
  p += F("<div style='display:flex;align-items:center'><select id=fxwx style='flex:1'><option value="); p += String((int)FX_RAIN); p += '>'; T(W_WX_RAIN);
  p += F("</option><option value="); p += String((int)FX_SNOW); p += '>'; T(W_WX_SNOW);
  p += F("</option><option value="); p += String((int)FX_STORM); p += '>'; T(W_WX_STORM); p += F("</option></select>");
  play("f", "fxwx.value"); p += F("</div><small>"); T(W_FX_NOTE);
  p += F("</small><button type=button class=sec onclick=\"snd('s',0)\">"); T(W_SND_STOP);
  p += F("</button><script>function snd(k,n){fetch('/sndtest',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},"
         "body:'k='+k+'&n='+n+'&v='+document.getElementById('svol').value});}</script>");
  p += F("<h2>"); T(W_R_ALARM);
#else
  p += F("<section class=tab id=t-sound><h2>"); T(W_R_BUZZ); p += F("</h2>");
  if (!bz::present()) { p += F("<small>"); T(W_BZ_NOCFG); p += F("</small>"); }
  p += F("<label><input type=checkbox name=bzhr value=1"); chk(gSet.bzHour);
  p += F(">"); T(W_BZ_HOUR); p += F("</label><label><input type=checkbox name=bzq value=1"); chk(gSet.bzQuiet);
  p += F(">"); T(W_BZ_QUIET); p += F("</label>");
#if HAS_TOUCH
  p += F("<label><input type=checkbox name=bztc value=1"); chk(gSet.bzTouch);
  p += F(">"); T(W_BZ_TOUCH); p += F("</label>");
#endif
  p += F("<button type=submit class=sec formaction=/beep formmethod=post formnovalidate>"); T(W_BZ_TEST);
  p += F("</button><h2>"); T(W_R_ALARM);
#endif
  p += F("</h2><label><input type=checkbox name=alon value=1"); chk(gSet.alOn);
  p += F(">"); T(W_AL_ON); p += F("</label><label>"); T(W_AL_TIME); p += F("</label><input type=time name=alt value=\"");
  p += hhmm(gSet.alTime);
  p += F("\"><label>"); T(W_AL_DAYS); p += F("</label><div class=chips style='flex-wrap:wrap'>");
  for (int i = 0; i < 7; i++) {               // Montag zuerst
    p += F("<label style='display:inline-flex;align-items:center;gap:.3em;margin-right:.8em'><input type=checkbox name=ald");
    p += String(i);
    p += F(" value=1");
    p += (gSet.alDays & (1 << i)) ? F(" checked>") : F(">");
    p += WEEKDAY2[(i + 1) % 7];
    p += F("</label>");
  }
  p += F("</div>");
#if SND_RICH
  p += F("<label>"); T(W_AL_TONE); p += F("</label>");
  opts("altone", W_ALT0, SND_AL_COUNT, gSet.alTone); play("a", "altone.value"); p += F("</div>");
#endif
  if (gAlarmRinging) { p += F("<button type=submit class=red formaction=/alarmoff formmethod=post formnovalidate>"); T(W_AL_STOP); p += F("</button>"); }
  p += F("<small>"); T(W_AL_HINT); p += F("</small></section>");

  // ================= WLAN =================
  fl();
  p += F("<section class=tab id=t-net><h2>"); T(W_WIFI); p += F("</h2><label>"); T(W_SSID); p += F("</label><input name=ssid list=ssids maxlength=32 value=\"");
  p += esc(gSet.ssid);
  p += F("\"><datalist id=ssids></datalist><button type=button class=sec id=sb onclick=scan()>"); T(W_SCAN);
  p += F("</button><label>"); T(W_PASS); p += F("</label><input name=pass type=password maxlength=64 placeholder=\""); p += esc(TR(W_PASS_PH));
  p += F("\" autocomplete=new-password><small>"); T(W_WIFI_HINT); p += F("</small></section>");

  // ================= Zeit & Wetter =================
  fl();
  p += F("<section class=tab id=t-time><h2>"); T(W_H_TIME); p += F("</h2><label>"); T(W_TZ); p += F("</label><select name=tz>");
  bool found = false;
  for (const TzEntry& z : TZS) {
    bool s = (strcmp(gSet.tz, z.posix) == 0);
    found |= s;
    p += F("<option value=\""); p += esc(z.posix); p += s ? F("\" selected>") : F("\">");
    p += esc(z.name); p += F("</option>");
  }
  p += F("</select><label>"); T(W_TZC); p += F("</label><input name=tzc maxlength=63 placeholder=\""); p += esc(TR(W_EG));
  p += F(" CET-1CEST,M3.5.0,M10.5.0/3\" value=\"");
  p += found ? String("") : esc(gSet.tz);
  p += F("\"><label><input type=checkbox name=ntpon value=1"); chk(gSet.ntpOn);
  p += F(">"); T(W_NTP_CB); p += F("</label><label>"); T(W_NTP_SRV); p += F("</label><input name=ntp maxlength=47 value=\"");
  p += esc(gSet.ntp);
  p += F("\"><small>"); T(W_NTP_HINT); p += F("</small>");
  {
    char dv[12] = "", tv[10] = "";
    if (timeValid()) {
      time_t n = time(nullptr); struct tm t; localtime_r(&n, &t);
      strftime(dv, sizeof(dv), "%Y-%m-%d", &t);
      strftime(tv, sizeof(tv), "%H:%M:%S", &t);
    }
    p += F("<h2>"); T(W_H_MANUAL); p += F("</h2><label>"); T(W_DATE); p += F("</label><input type=date name=mdate min=2024-01-01 max=2099-12-31 value=\"");
    p += dv;
    p += F("\"><label>"); T(W_R_TIME); p += F("</label><input type=time name=mtime step=1 value=\"");
    p += tv;
    p += F("\"><div style='margin:.5em 0'>"
           "<button type=button class=sec onclick=\"var d=new Date(),z=n=>('0'+n).slice(-2),f=this.form;"
           "f.mdate.value=d.getFullYear()+'-'+z(d.getMonth()+1)+'-'+z(d.getDate());"
           "f.mtime.value=z(d.getHours())+':'+z(d.getMinutes())+':'+z(d.getSeconds())\">"); T(W_BROWSER_T);
    p += F("</button> <button type=submit formaction=/settime formmethod=post formnovalidate>"); T(W_SET_TIME);
    p += F("</button></div><small>"); T(W_MAN_HINT); p += F("</small>");
  }
  p += F("<h2>"); T(W_R_WX); p += F("</h2><label>"); T(W_GEO);
  p += F("</label><div style='display:flex;gap:.5em'><input id=geoq style='flex:1' maxlength=60 autocomplete=off placeholder=\"");
  T(W_GEO_PH);
  p += F("\" onkeydown=\"if(event.key==='Enter'){event.preventDefault();geoFind()}\"><button type=button class=sec style='margin:0' onclick=geoFind()>");
  T(W_GEO_BTN);
  p += F("</button></div><div id=geor></div><small>"); T(W_GEO_HINT); p += F("</small>");
  p += F("<label>"); T(W_LAT); p += F("</label><input name=lat inputmode=decimal value=\"");
  p += String(gSet.lat, 4);
  p += F("\"><label>"); T(W_LON); p += F("</label><input name=lon inputmode=decimal value=\"");
  p += String(gSet.lon, 4);
  p += F("\"><label>"); T(W_UPD); p += F("</label><input name=upd type=number min=5 max=120 value=");
  p += String(gSet.updMin);
  p += F("><h2>"); T(W_H_RADAR); p += F("</h2><label>"); T(W_RADIUS); p += F("</label><input name=rkm type=number min=5 max=100 value=");
  p += String(gSet.radarKm);
  p += F("><small>"); T(W_RADAR_HINT); p += F("</small></section>");

  // ================= Kalender =================
  fl();
  p += F("<section class=tab id=t-cal><h2>"); T(W_TAB_CAL); p += F("</h2><label>"); T(W_CAL_BL); p += F("</label><select name=calbl>");
  for (int i = 0; i <= 16; i++) {
    p += F("<option value="); p += String(i); sel(gSet.calBl == i); p += '>';
    if (i == 0) T(W_CAL_NONE); else p += cal::BL_NAME[i];
    p += F("</option>");
  }
  p += F("</select><label>"); T(W_CAL_SHOW); p += F("</label>");
  {
    static const uint16_t CFT[5] = {W_CAL_PUB, W_CAL_SPEC, W_CAL_SCHOOL, W_CAL_POP, W_CAL_TICK};
    for (int i = 0; i < 5; i++) {
      p += F("<label><input type=checkbox name=cf"); p += String(i); p += F(" value=1"); chk(gSet.calFlags & (1 << i)); p += '>'; T(CFT[i]); p += F("</label>");
    }
  }
  p += F("<label>"); T(W_CAL_POPMIN); p += F("</label><select name=calpop>");
  { static const uint8_t V[6] = {5, 10, 15, 20, 30, 60};
    for (uint8_t v : V) { p += F("<option value="); p += String(v); sel(gSet.calPop == v); p += '>'; p += String(v); p += ' '; T(W_CAL_MIN); p += F("</option>"); } }
  p += F("</select><label>"); T(W_CAL_TICKMIN); p += F("</label><select name=caltick>");
  { static const uint8_t V[6] = {10, 15, 30, 60, 120, 240};
    for (uint8_t v : V) { p += F("<option value="); p += String(v); sel(gSet.calTick == v); p += '>'; p += String(v); p += ' '; T(W_CAL_MIN); p += F("</option>"); } }
  p += F("</select><small id=calst></small><label>"); T(W_CAL_TEST); p += F("</label><div style='display:flex;gap:.5em'><select id=calid style='flex:1'>");
  for (int i = 0; i < cal::CD_COUNT; i++) { p += F("<option value="); p += String(i); p += '>'; p += cal::name(i); p += F("</option>"); }
  p += F("</select><button type=button class=sec style='margin:0' onclick=calPop()>"); T(W_CAL_TESTBTN);
  p += F("</button></div><small>"); T(W_CAL_HINT); p += F("</small><h2>"); T(W_H_CALYEAR);
  p += F("</h2><style>.calv{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:.8em;margin:.6em 0}"
         ".calm b{display:block;margin-bottom:.2em;text-transform:capitalize}.calg{display:grid;grid-template-columns:repeat(7,1fr);gap:1px;font-size:.72rem;text-align:center}"
         ".calg i{font-style:normal;padding:2px 0;border-radius:3px}.calg .h{color:#8b949e}.calg .su{color:#e07070}.calg .f{background:#1f3a6e}"
         ".calg .s{box-shadow:inset 0 -2px #f0a030}.calg .p{background:#a8323a;color:#fff}.calg .t{outline:2px solid var(--acc)}"
         "table.calt{width:100%;font-size:.85rem;border-collapse:collapse}.calt td{padding:3px 4px;border-bottom:1px solid #30363d}"
         ".calt tr.p td+td{color:#ff7b72}.calt tr.s td+td{color:#f0a030}.calt tr.f td+td{color:#79c0ff}.calk span{margin-right:1em;white-space:nowrap}</style>"
         "<div style='display:flex;align-items:center;gap:.8em'><button type=button class=sec style='margin:0' onclick=calY(-1)>&lt;</button>"
         "<b id=caly></b><button type=button class=sec style='margin:0' onclick=calY(1)>&gt;</button></div>"
         "<div class=calk id=calk></div><div class=calv id=calv></div><table class=calt id=call></table>"
         "<script>let cy=0,cdat=null;function calY(d){cy+=d;calLoad();}"
         "function calLoad(){fetch('/cal.json?y='+(new Date().getFullYear()+cy),{cache:'no-store'}).then(r=>r.json()).then(j=>{cdat=j;calDraw();}).catch(()=>{});}"
         "function calPop(){fetch('/calpop',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+document.getElementById('calid').value});}"
         "function calDraw(){const j=cdat,y=j.y,g=i=>document.getElementById(i),lg=L.glang;g('caly').textContent=y;"
         "const M={};j.days.forEach(d=>{const k=d[0]*100+d[1];(M[k]=M[k]||[]).push(d);});"
         "const F=j.fer.map(f=>[new Date(f[0]+'T12:00'),new Date(f[1]+'T12:00'),f[2]]),isF=dt=>F.find(f=>dt>=f[0]&&dt<=f[1]);"
         "const now=new Date().toDateString();let h='';const wd=[];for(let i=0;i<7;i++)wd.push(new Date(2024,0,1+i).toLocaleString(lg,{weekday:'narrow'}));"
         "for(let m=0;m<12;m++){const f1=new Date(y,m,1,12),n=new Date(y,m+1,0).getDate(),off=(f1.getDay()+6)%7;"
         "h+='<div class=calm><b>'+f1.toLocaleString(lg,{month:'long'})+'</b><div class=calg>';wd.forEach(w=>h+='<i class=h>'+w+'</i>');"
         "for(let i=0;i<off;i++)h+='<i></i>';"
         "for(let d=1;d<=n;d++){const dt=new Date(y,m,d,12),e=M[(m+1)*100+d],fe=isF(dt);let c='';"
         "if(fe)c+=' f';if(e&&e.some(x=>x[2]==1))c+=' p';else if(e)c+=' s';if(dt.getDay()==0)c+=' su';if(dt.toDateString()==now)c+=' t';"
         "const tip=[...(e?e.map(x=>x[3]):[]),...(fe?[fe[2]]:[])].join(', ');h+='<i class=\"'+c+'\" title=\"'+tip+'\">'+d+'</i>';}"
         "h+='</div></div>';}g('calv').innerHTML=h;"
         "const R=[];const fd=(s,o)=>new Date(s+'T12:00').toLocaleDateString(lg,o||{weekday:'short',day:'numeric',month:'short'});"
         "j.days.forEach(d=>{const s=y+'-'+String(d[0]).padStart(2,'0')+'-'+String(d[1]).padStart(2,'0');R.push([s,d[2]==1?'p':'s',fd(s),d[3]]);});"
         "j.fer.forEach(f=>R.push([f[0],'f',fd(f[0],{day:'numeric',month:'short'})+' &ndash; '+fd(f[1],{day:'numeric',month:'short'}),f[2]]));"
         "R.sort((a,b)=>a[0]<b[0]?-1:1);g('call').innerHTML=R.map(r=>'<tr class='+r[1]+'><td>'+r[2]+'</td><td>'+r[3]+'</td></tr>').join('');"
         "g('calk').innerHTML='<span style=\"color:#ff7b72\">&#9632; '+L.cpub+'</span><span style=\"color:#f0a030\">&#9632; '+L.cspec+'</span><span style=\"color:#79c0ff\">&#9632; '+L.cfer+'</span>';"
         "let st='';if(j.bl){st=j.ferN?L.cfok+j.ferN+' ('+new Date(j.fetched*1000).toLocaleDateString(lg)+')':L.cfno;if(j.err)st+=' '+L.cferr+j.err;}g('calst').textContent=st;}"
         "window.addEventListener('load',calLoad);</script></section>");

  // ================= System =================
  fl();
  p += F("<section class=tab id=t-sys><h2>"); T(W_H_DEVICE); p += F("</h2><label>"); T(W_HOST_LBL); p += F("</label><input name=host maxlength=23 value=\"");
  p += esc(gSet.host);
  p += F("\"><h2>"); T(W_H_ACCESS); p += F("</h2><label>"); T(W_WEBPW);
  p += F("</label><input name=webpw type=password maxlength=32 autocomplete=new-password><label><input type=checkbox name=rmpw value=1>"); T(W_RMPW);
  p += F("</label><h2>"); T(W_H_FW); p += F("</h2><label>"); T(W_INSTALLED); p += F("<b>");
  p += FW_VERSION;
  p += F("</b> ("); T(W_BUILT); p += ' '; p += __DATE__; p += ' '; p += __TIME__; p += F(")</label>");
  if (!otaPartition()) {
    p += F("<div class=warn>"); T(W_NO_OTA); p += F("</div>");
  } else {
    snprintf(fb, sizeof(fb), TR(W_FW_FILE), (unsigned long)(otaMaxSize() / 1024));
    p += F("<label>"); p += fb; p += F("</label><input type=file id=fw accept=.bin><button type=button id=fwb onclick=fwUp()>"); T(W_FW_INST);
    p += F("</button><div id=fwp style='margin-top:.6em'></div>"
         "<div style='height:10px;background:#161b22;border:1px solid #30363d;border-radius:5px;overflow:hidden;margin:.4em 0'>"
         "<div id=fwbar style='height:100%;width:0;background:#238636;transition:width .2s'></div></div><small>"); T(W_FW_HINT1);
    p += esc(gSet.host);
    T(W_FW_HINT2);
    // Ablauf im Browser: /fwprep fragt, ob direkt oder ueber RetroCYD (CYD mit Spielen: die Uhr kann sich nicht
    // selbst ueberschreiben). Bei "relay" startet die Uhr RetroCYD im Update-Modus, die Seite wartet auf /fwready
    // (gleiche IP) und schickt die Datei dann dorthin; RetroCYD schreibt die neue Uhr und startet sie.
    p += F("</small><script>"
           // Inhalt pruefen (nicht den Namen): Chip im Kopf, Programm-Kennung (kein Bootloader/Erstinstallation),
           // welches Programm (Uhr / RetroCYD) - die Kennungen stehen um 1 verschoben hier, damit sie nicht in der Uhr selbst stecken
           "async function fwKind(f){const b=new Uint8Array(await f.arrayBuffer()),n=b.length;if(n<4096)return'bad';"
           "if(b[0]!=0xE9)return(b[0]==0xFF&&n>0x9000&&b[0x1000]==0xE9)?'merged':'bad';"
           "if(!(b[32]==0x32&&b[33]==0x54&&b[34]==0xCD&&b[35]==0xAB))return'merged';"
           "if((b[12]|b[13]<<8)!=L.chip)return'board';"
           "const has=e=>{const m=[...e].map(c=>c.charCodeAt(0)-1),l=m.length;o:for(let i=0;i<=n-l;i++){if(b[i]!=m[0])continue;for(let k=1;k<l;k++)if(b[i+k]!=m[k])continue o;return true;}return false;};"
           "if(has('SFUSPDZE.BQQ.JE.2'))return'games';if(has('XFUUFSVIS.BQQ.JE.2'))return'clock';return L.cyd?'old':'clock';}"
           "function fwUp(){const f=$('fw').files[0],o=$('fwp'),b=$('fwb');"
           "if(!f){o.textContent=L.pick;return;}"
           "b.disabled=true;const fail=m=>{o.textContent=m;b.disabled=false;};o.textContent=L.fchk;"
           "fwKind(f).then(k=>{"
           "if(k=='merged')return fail(L.fmrg);if(k=='board')return fail(L.fbrd);if(k=='old')return fail(L.fold);if(k!='clock'&&k!='games')return fail(L.fbad);"
           "if(k=='games'&&!L.cyd)return fail(L.fbrd);"
           "o.textContent=k=='games'?L.fgam:L.fclk;"
           "if(!confirm(f.name+'\\n'+(k=='games'?L.fgam:L.fclk)+'\\n'+L.conf)){b.disabled=false;return;}"
           "if(k=='games'||!L.games){fwSend(f,'',k);return;}"
           "o.textContent=L.relay;"
           "fetch('/fwrelay',{method:'POST'}).then(r=>r.text()).then(t=>{const t0=Date.now();"
           "const poll=()=>{if(Date.now()-t0>120000){fail(L.lost);return;}"
           "fetch('/fwready?t='+t,{cache:'no-store'}).then(r=>r.text()).then(x=>{if(x=='ready')fwSend(f,t,k);else setTimeout(poll,2000);})"
           ".catch(()=>setTimeout(poll,2000));};setTimeout(poll,5000);}).catch(()=>fail(L.lost));"
           "}).catch(()=>fail(L.fbad));}"
           "function fwSend(f,t,k){const o=$('fwp'),b=$('fwb');const x=new XMLHttpRequest();"
           "x.open('POST','/update?size='+f.size+'&app='+k+(t?'&t='+t:''));"
           "x.upload.onprogress=e=>{if(e.lengthComputable){const q=Math.round(e.loaded*100/e.total);o.textContent=L.sent+q+' %';$('fwbar').style.width=q+'%';}};"
           "x.onload=()=>{let j=null;try{j=JSON.parse(x.responseText);}catch(e){}"
           "if(x.status==200&&(x.responseText=='OK'||(j&&j.ok))){o.textContent=L.done;setTimeout(()=>location.href='/',25000);}"
           "else if(x.status==200&&!j){o.textContent=x.responseText;b.disabled=false;$('fwbar').style.width='100%';if(k=='games'&&confirm(L.gst))fetch('/games',{method:'POST'});}"
           "else{o.textContent=L.err+(j&&j.err?j.err:x.responseText);b.disabled=false;}};"
           "x.onerror=()=>{o.textContent=L.lost;b.disabled=false;};"
           "const d=new FormData();d.append('firmware',f,f.name);x.send(d);}</script>");
  }
#if BOARD_CYD
  // Zweites Programm RetroCYD (Spiele) und Touch-Kalibrierung
  p += F("<h2>"); T(W_H_GAMES); p += F("</h2><p>"); T(dual::games() ? W_G_YES : W_G_NO); p += F("</p>");
  if (dual::games()) { p += F("<button type=submit class=sec formaction=/games formmethod=post formnovalidate>"); T(W_G_START); p += F("</button> "); }
  p += F("<button type=submit class=sec formaction=/tcal formmethod=post formnovalidate>"); T(W_TCAL); p += F("</button><small>"); T(W_G_HINT); p += F("</small>");
#endif
  // Display-Anpassung: Controller, Drehung/Spiegelung, Farben (wirkt sofort nach "Speichern")
  p += F("<h2>"); T(W_H_PANEL); p += F("</h2>");
#if BOARD_CYD
  p += F("<label>"); T(W_PANEL_CTL); p += F("</label><select name=panel>");
  for (int i = 0; i < 3; i++) {
    p += F("<option value="); p += String(i); sel(gSet.panel == i); p += '>';
    if (i == 0) { T(W_PANEL_AUTO); p += F(" ("); p += gPanelUsed == PANEL_ST7789 ? F("ST7789") : F("ILI9341"); p += ')'; }
    else p += i == 1 ? F("ILI9341") : F("ST7789");
    p += F("</option>");
  }
  p += F("</select>");
#endif
  for (int i = 0; i < 5; i++) {
    p += F("<label><input type=checkbox name=pf"); p += String(i); p += F(" value=1"); chk(gSet.pflags & (1 << i));
    p += '>'; T(W_PF0 + i); p += F("</label>");
  }
  p += F("<small>"); T(W_PANEL_HINT); p += F("</small>");

  p += F("<h2>"); T(W_H_RESET); p += F("</h2><button type=submit class=red formaction=/reset formmethod=post formnovalidate "
         "onclick=\"return confirm(L.reset)\">"); T(W_FACTORY); p += F("</button></section>");

  p += F("<div id=savebar><button type=submit>"); T(W_SAVE); p += F("</button></div></form></main></div>");
  // Texte fuer das JavaScript der Seite
  auto js = [&](const char* k, uint16_t id) { p += k; p += F(":\""); p += jsonEsc(TR(id)); p += F("\","); };
  p += F("<script>const L={");
  js("scan", W_SCANNING); js("found", W_FOUND); js("scanb", W_SCAN); js("pick", J_PICK); js("wrong", J_WRONG); js("conf", J_CONFIRM);
  js("fmrg", J_F_MERGED); js("fbrd", J_F_BOARD); js("fbad", J_F_BAD); js("fold", J_F_OLD); js("fchk", J_F_CHECK);
  js("fgam", J_F_GAMES); js("fclk", J_F_CLOCK); js("gst", J_F_GSTART);
  p += F("chip:"); p += String((int)CONFIG_IDF_FIRMWARE_CHIP_ID); p += F(",cyd:"); p += BOARD_CYD ? '1' : '0';
#if BOARD_CYD
  p += F(",games:"); p += dual::games() ? '1' : '0'; p += ',';
#else
  p += F(",games:0,");
#endif
  js("sent", J_SENT); js("relay", J_RELAY); js("done", J_DONE); js("err", J_ERR); js("lost", J_LOST); js("reset", W_RESET_Q);
  js("cpub", J_CAL_PUB); js("cspec", J_CAL_SPEC); js("cfer", J_CAL_FER); js("cfok", J_CAL_FEROK); js("cfno", J_CAL_FERNO); js("cferr", J_CAL_FERERR);
  js("gw", J_GEO_WAIT); js("gn", J_GEO_NONE); js("ge", J_GEO_ERR); js("gok", J_GEO_OK); js("gsv", J_GEO_SAVE);
  p += F("glang:\""); p += LANG_CODE[LANG_IDX]; p += F("\",");
  p += F("};</script>");
  p += FPSTR(PAGE_JS);
  server.sendContent(p);
  server.sendContent("");               // Ende der Antwort
}

// Ortssuche ueber die Uhr (nur wenn der Browser Open-Meteo nicht selbst erreicht)
static void handleGeo() {
  if (!authOk()) return;
  String q = server.arg("q"); q.trim();
  if (q.length() < 2 || q.length() > 60 || WiFi.status() != WL_CONNECTED) { server.send(502, "application/json", "{\"error\":true}"); return; }
  String u = F("https://geocoding-api.open-meteo.com/v1/search?count=8&format=json&language=");
  u += LANG_CODE[LANG_IDX]; u += F("&name=");
  static const char hx[] = "0123456789ABCDEF";
  for (size_t i = 0; i < q.length(); i++) {
    const uint8_t c = (uint8_t)q[i];
    if (isalnum(c) || c == '-' || c == '.' || c == '_') u += (char)c;
    else { u += '%'; u += hx[c >> 4]; u += hx[c & 15]; }
  }
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setConnectTimeout(8000);
  http.setTimeout(8000);
  if (!http.begin(client, u)) { server.send(502, "application/json", "{\"error\":true}"); return; }
  const int code = http.GET();
  if (code != HTTP_CODE_OK) { http.end(); server.send(502, "application/json", "{\"error\":true}"); return; }
  const String body = http.getString();
  http.end();
  server.send(200, "application/json", body);
}

static void handleSave() {
  if (!authOk()) return;
  Settings n = gSet;
  String s;

  s = server.arg("ssid"); s.trim();
  if (s.length() <= 32) strlcpy(n.ssid, s.c_str(), sizeof(n.ssid));

  s = server.arg("pass");
  if (s.length() > 0 && s.length() <= 64) strlcpy(n.pass, s.c_str(), sizeof(n.pass));

  String tzc = server.arg("tzc"); tzc.trim();
  String tzs = server.arg("tz");  tzs.trim();
  String tz = tzc.length() ? tzc : tzs;
  if (tz.length() >= 1 && tz.length() <= 63) strlcpy(n.tz, tz.c_str(), sizeof(n.tz));

  s = server.arg("ntp"); s.trim();
  if (s.length() >= 1 && s.length() <= 47) strlcpy(n.ntp, s.c_str(), sizeof(n.ntp));

  s = server.arg("lat"); s.trim(); s.replace(',', '.');
  if (s.length()) { float v = s.toFloat(); if (v >= -90.0f && v <= 90.0f) n.lat = v; }
  s = server.arg("lon"); s.trim(); s.replace(',', '.');
  if (s.length()) { float v = s.toFloat(); if (v >= -180.0f && v <= 180.0f) n.lon = v; }

  int upd = server.arg("upd").toInt();
  if (upd >= 5 && upd <= 120) n.updMin = (uint16_t)upd;
  int rkm = server.arg("rkm").toInt();
  if (rkm >= 5 && rkm <= 100) n.radarKm = (uint8_t)rkm;

  int b = server.arg("b").toInt();
  if (b >= 5 && b <= 100) n.bright = (uint8_t)b;

  if (server.hasArg("cs"))  { int v = server.arg("cs").toInt();  if (v >= 0 && v < CLOCK_STYLE_COUNT) n.clockStyle = (uint8_t)v; }
  if (server.hasArg("acc")) { int v = server.arg("acc").toInt(); if (v >= 0 && v < ACCENT_COUNT)      n.accent = (uint8_t)v; }

  n.tickOn   = server.hasArg("tkon");
  n.tickLoop = server.arg("tkmode") == "1";
  n.tickBg   = server.hasArg("tkbg");
  { int v = server.arg("tkpos").toInt();   if (v >= 0 && v <= 2)    n.tickPos = (uint8_t)v; }
  { int v = server.arg("tkbig").toInt();   if (v == 0 || v == 1)    n.tickBig = (uint8_t)v; }
  { int v = server.arg("tkcol").toInt();   if (v >= 0 && v <= 9)    n.tickColor = (uint8_t)v; }
  { int v = server.arg("tkspd").toInt();   if (v >= 1 && v <= 10)   n.tickSpeed = (uint8_t)v; }
  { String v = server.arg("tkpause"); if (v.length()) { long x = v.toInt(); if (x >= 0 && x <= 3600) n.tickPause = (uint16_t)x; } }
  if (server.hasArg("tk")) {
    String t = server.arg("tk"); t.trim();
    if (t.length() <= 160) strlcpy(n.tick, t.c_str(), sizeof(n.tick));
  }
  n.autoOn  = server.hasArg("auto");
  n.autoRnd = server.hasArg("arnd");
  {
    uint64_t m = 0;
    for (int i = 0; i < CLOCK_STYLE_COUNT; i++) if (server.hasArg(String("am") + i)) m |= (1ULL << i);
    n.autoMask = m;
    long v = server.arg("aint").toInt(), u = server.arg("aunit").toInt();
    if (u != 1 && u != 60 && u != 3600) u = 60;
    if (v >= 1 && v * u >= 10 && v * u <= 86400) n.autoSec = (uint32_t)(v * u);
  }

  n.dimOn = server.hasArg("dim");
  n.dimTv = server.hasArg("dimtv");
  n.ntpOn   = server.hasArg("ntpon");
  n.bzHour  = server.hasArg("bzhr");
  n.bzQuiet = server.hasArg("bzq");
#if HAS_TOUCH
  n.bzTouch = server.hasArg("bztc");
#endif
  n.alOn    = server.hasArg("alon");
#if SND_RICH
  if (server.hasArg("svol")) {                         // Lautsprecher (nur CYD, nur wenn die Felder auf der Seite sind)
    n.sndVol = (uint8_t)constrain(server.arg("svol").toInt(), 5, 100);
    n.alTone = (uint8_t)constrain(server.arg("altone").toInt(), 0, SND_AL_COUNT - 1);
    n.hrTone = (uint8_t)constrain(server.arg("hrtone").toInt(), 0, SND_HR_COUNT - 1);
    n.sndFx = 0;
    for (int i = 0; i < 5; i++) if (server.hasArg(String("sfx") + i)) n.sndFx |= (uint8_t)(1 << i);
  }
#endif
  n.nyeAuto = server.hasArg("nyeauto");
  n.holAuto = server.hasArg("holauto");
  n.fine = (server.hasArg("fsm") ? 1 : 0) | (server.hasArg("ftx") ? 2 : 0);
  if (server.hasArg("calbl")) {                        // Kalender
    n.calBl = (uint8_t)constrain(server.arg("calbl").toInt(), 0, 16);
    n.calFlags = 0;
    for (int i = 0; i < 5; i++) if (server.hasArg(String("cf") + i)) n.calFlags |= 1 << i;
    n.calPop = (uint8_t)constrain(server.arg("calpop").toInt(), 5, 60);
    n.calTick = (uint8_t)constrain(server.arg("caltick").toInt(), 5, 240);
    if (n.calBl != gSet.calBl) cal::ferTriedMs = 0;     // neues Bundesland: Ferien gleich abrufen
  }
#if PIN_LED_R >= 0
  if (server.hasArg("ledm")) {
    n.ledMode = (uint8_t)constrain(server.arg("ledm").toInt(), 0, 6);
    String c = server.arg("ledc"); c.replace("#", "");
    if (c.length() == 6) n.ledCol = strtoul(c.c_str(), nullptr, 16) & 0xFFFFFF;
    n.ledBri = (uint8_t)constrain(server.arg("ledb").toInt(), 1, 100);
    n.ledTime = (uint8_t)constrain(server.arg("ledt").toInt(), 0, 2);
    n.ledHint = 0;
    for (int i = 0; i < 4; i++) if (server.hasArg(String("lh") + i)) n.ledHint |= 1 << i;
  }
#endif
  if (server.hasArg("panel")) { int v = server.arg("panel").toInt(); n.panel = (v >= 0 && v <= 2) ? (uint8_t)v : 0; }
  n.pflags = 0;
  for (int i = 0; i < 5; i++) if (server.hasArg(String("pf") + i)) n.pflags |= (1 << i);
  { int v = server.arg("lang").toInt(); if (server.hasArg("lang") && v >= 0 && v < LANG_COUNT) n.lang = (uint8_t)v; }
  n.ufoOn   = server.hasArg("ufo");
  { int v = server.arg("sled").toInt(); if (v >= 0 && v <= 2) n.sleigh = (uint8_t)v; }
  { uint16_t v; if (parseHhmm(server.arg("alt"), v)) n.alTime = v; }
  { uint8_t m = 0; for (int i = 0; i < 7; i++) if (server.hasArg(String("ald") + i)) m |= (uint8_t)(1 << i); n.alDays = m; }
  { uint16_t v; if (parseHhmm(server.arg("dims"), v)) n.dimStart = v; if (parseHhmm(server.arg("dime"), v)) n.dimEnd = v; }
  { int v = server.arg("diml").toInt(); if (v >= 5 && v <= 100) n.dimLevel = (uint8_t)v; }

  n.seconds  = server.hasArg("sec");
  n.rotation = (server.arg("rot").toInt() == 3) ? 3 : 1;

  String h = cleanHost(server.arg("host"));
  if (h.length() >= 1) strlcpy(n.host, h.c_str(), sizeof(n.host));

  String wp = server.arg("webpw");
  if (server.hasArg("rmpw")) n.webPw[0] = 0;
  else if (wp.length() > 0 && wp.length() <= 32) strlcpy(n.webPw, wp.c_str(), sizeof(n.webPw));

  const bool reboot = strcmp(n.ssid, gSet.ssid) || strcmp(n.pass, gSet.pass) ||
                      strcmp(n.ntp, gSet.ntp)   || strcmp(n.host, gSet.host);
  const bool rotChanged = (n.rotation != gSet.rotation) || (n.pflags != gSet.pflags);
  const bool panelChanged = (n.panel != gSet.panel);
  const bool brChanged  = (n.bright != gSet.bright);
  const bool ntpChanged = (n.ntpOn != gSet.ntpOn);

  const bool csChanged = (n.clockStyle != gSet.clockStyle);
  gSet = n;
  settingsSave();
  bz::setVolume(gSet.sndVol);
  gHolAt = 0;                                         // Feiertags-Fenster neu berechnen
  if (ntpChanged) {                     // NTP ein/aus ohne Neustart
    if (!gSet.ntpOn) ntpStop();
    ntpStarted = false;                 // wifiLoop startet NTP bei Bedarf neu
  }
  if (csChanged || !autoActive()) styleManual();   // Design geaendert oder kein Wechsel: gewaehltes Design zeigen
  else if (!inList(gStyle)) {                       // Wechsel aktiv: weiterlaufen, nur bei Bedarf in die Liste springen
    gStyle = (uint8_t)nextStyle(gStyle); gStyleSince = millis(); needFull = true;
  }
  tickerRestart();

  applyTimezone();
  dimTick(millis(), true);
  themeApply();
  if (panelChanged) { displayInit(); setBrightness(gSet.bright, false); }   // anderer Controller: Display neu starten
  else if (rotChanged) boardPanelApply(gSet.rotation, gSet.pflags);
  if (brChanged)  setBrightness(gSet.bright, false);
  gRefreshNow = true;   // Wetter mit neuen Koordinaten sofort neu abrufen
  needFull = true;

  if (reboot) {
    server.send(200, "text/html; charset=utf-8",
      String(F("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
        "<body style='font-family:sans-serif;background:#0d1117;color:#e6edf3;padding:20px'>")) + TR(W_PG_SAVED) + "</body>");
    needReboot = true;
    rebootAt = millis() + 1500;
  } else {
    server.sendHeader("Location", "/?saved=1");
    server.send(303);
  }
}

static void handleBrightness() {
  if (!authOk()) return;
  int v = server.arg("v").toInt();
  if (v < 5 || v > 100) { server.send(400, "text/plain; charset=utf-8", TR(W_INVALID)); return; }
  setBrightness((uint8_t)v, true);
  server.send(204);
}

static void handleLook() {
  if (!authOk()) return;
  int cs = server.arg("cs").toInt();
  int ac = server.arg("acc").toInt();
  if (cs < 0 || cs >= CLOCK_STYLE_COUNT || ac < 0 || ac >= ACCENT_COUNT) {
    server.send(400, "text/plain; charset=utf-8", TR(W_INVALID));
    return;
  }
  gSet.clockStyle = (uint8_t)cs;
  gDbgLook = cs;
  gSet.accent = (uint8_t)ac;
  styleManual();
  gDbgSrc = 'W';
  themeApply();
  needFull = true;                       // komplett neu zeichnen
  setDirty = true; setDirtyAt = millis();  // nach 3 s Ruhe im Flash speichern
  server.send(204);
}

static void handleTicker() {
  if (!authOk()) return;
  if (gSet.tick[0] && !standby) gTickNow = true;
  server.send(204);
}

static void handleStandby() {
  if (!authOk()) return;
  if (server.arg("v") == "1") { if (!standby) enterStandby(); }
  else if (standby) startWake();
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void handleScan() {
  if (!authOk()) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_FAILED) {            // noch kein Scan gestartet
    WiFi.scanNetworks(true);              // asynchron, blockiert nicht
    server.send(200, "application/json", F("{\"state\":\"running\"}"));
    return;
  }
  if (n == WIFI_SCAN_RUNNING) {
    server.send(200, "application/json", F("{\"state\":\"running\"}"));
    return;
  }
  String j = F("{\"state\":\"done\",\"list\":[");
  bool first = true;
  for (int i = 0; i < n && i < 20; i++) {
    String name = WiFi.SSID(i);
    if (name.length() == 0) continue;
    if (!first) j += ',';
    first = false;
    j += '"'; j += jsonEsc(name); j += '"';
  }
  j += F("]}");
  WiFi.scanDelete();
  server.send(200, "application/json", j);
}

static void handleReset() {
  if (!authOk()) return;
  settingsFactoryReset();
  server.send(200, "text/html; charset=utf-8",
    String(F("<!doctype html><meta charset=utf-8><body style='font-family:sans-serif;background:#0d1117;color:#e6edf3;padding:20px'>")) +
      TR(W_PG_RESET) + "</body>");
  needReboot = true;
  rebootAt = millis() + 1500;
}

static void handleSetTime() {
  if (!authOk()) return;
  int y = 0, mo = 0, d = 0, h = 0, mi = 0, s = 0;
  const String ds = server.arg("mdate"), ts = server.arg("mtime");
  const bool okD = sscanf(ds.c_str(), "%d-%d-%d", &y, &mo, &d) == 3;
  const int nt = sscanf(ts.c_str(), "%d:%d:%d", &h, &mi, &s);
  if (!okD || nt < 2 || !setLocalTime(y, mo, d, h, mi, nt == 3 ? s : 0)) {
    server.send(400, "text/plain; charset=utf-8", TR(W_BAD_TIME));
    return;
  }
  LOGF("Uhrzeit manuell gesetzt: %s %s\n", ds.c_str(), ts.c_str());
  dimTick(millis(), true);
  resetCaches();
  needFull = true;
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void handleBeep() {
  if (!authOk()) return;
  if (!gAlarmRinging) bz::test();
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void handleAlarmOff() {
  if (!authOk()) return;
  alarmStop();
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void handleUfo() {
  if (!authOk()) return;
  gSet.clockStyle = RADAR_STYLE;          // Flugradar anzeigen
  styleManual();
  gDbgSrc = 'W';
  f_radar::kick = true;                   // UFO sofort
  setDirty = true; setDirtyAt = millis();
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void showAqua() {
  gSet.clockStyle = AQUA_STYLE;
  styleManual();
  gDbgSrc = 'W';
  setDirty = true; setDirtyAt = millis();
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}
static void handleFeed()  { if (!authOk()) return; f_aqua::requestFeed();  showAqua(); }
static void handleVisit() { if (!authOk()) return; f_aqua::requestVisit(); showAqua(); }

// ---- Firmware-Update per Browser (POST /update, multipart) ----
static String gOtaErr;
static size_t gOtaSize = 0;
#if BOARD_CYD
static cyd::App gOtaApp = cyd::APP_NONE;   // welches Programm gerade hochgeladen wird
static cyd::MarkScan gOtaScan;             // prueft die Kennung in der Datei
#endif

static bool gOtaFirst = false;              // naechster Block ist der Anfang der Datei
static void handleUpdateUpload() {
  HTTPUpload& up = server.upload();
  if (up.status == UPLOAD_FILE_START) {
    gOtaErr = "";
    gOtaFirst = true;
    if (gSet.webPw[0] && !server.authenticate("admin", gSet.webPw)) { gOtaErr = TR(W_E_LOGIN); return; }
    if (!otaPartition()) { gOtaErr = TR(W_E_NOPART); return; }
    gOtaSize = server.hasArg("size") ? (size_t)server.arg("size").toInt() : 0;
    if (gOtaSize > otaMaxSize()) {
      char e[96];
      snprintf(e, sizeof(e), TR(W_E_BIG), (unsigned long)(gOtaSize / 1024), (unsigned long)(otaMaxSize() / 1024));
      gOtaErr = e;
      return;
    }
#if BOARD_CYD
    // Zwei Programme: das Update wird in den anderen Programmbereich geschrieben. Dort steckt RetroCYD,
    // wenn es installiert ist - eine Uhr-Datei wuerde die Spiele ueberschreiben.
    {                                                  // welches Programm: vom Browser (Inhalt geprueft), sonst Dateiname
      const String a = server.arg("app");
      gOtaApp = a == "games" ? cyd::APP_GAMES : (a == "clock" ? cyd::APP_CLOCK : cyd::appFromName(up.filename));
    }
    if (gOtaApp != cyd::APP_GAMES && dual::games()) { gOtaErr = TR(W_E_CLOCK_IN_GAMES); return; }
    gOtaScan.begin(gOtaApp == cyd::APP_GAMES ? cyd::APP_GAMES : cyd::APP_CLOCK);
#endif
    LOGF("Update: %s, %u Bytes\n", up.filename.c_str(), (unsigned)gOtaSize);
    gOtaActive = true;
    otaScreen(0, TR(K_OTA_RECV));
    if (!Update.begin(gOtaSize ? gOtaSize : UPDATE_SIZE_UNKNOWN, U_FLASH)) { gOtaErr = Update.errorString(); otaResume(); }
  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (gOtaErr.length()) return;
    // Erster Block: Chip im Bild-Kopf pruefen (Byte 12/13), damit keine Firmware fuer das andere Board
    // (CYD = ESP32 bzw. ESP32-C3) eingespielt wird - sie wuerde nicht starten.
    // Nur der allererste Block: Update.progress() bleibt bis 4 KB bei 0 (Puffer), taugt dafuer also nicht
    if (gOtaFirst && up.currentSize >= 36) {
      gOtaFirst = false;
      const uint8_t* q = up.buf;
      const bool appDesc = q[0] == 0xE9 && q[32] == 0x32 && q[33] == 0x54 && q[34] == 0xCD && q[35] == 0xAB;
      const uint16_t chip = q[12] | (q[13] << 8);
      const char* e = nullptr;
      if (!appDesc) e = TR(W_E_MERGED);                // Erstinstallation / Bootloader / keine Programmdatei
      else if (chip != CONFIG_IDF_FIRMWARE_CHIP_ID) e = TR(W_E_BOARD);
      if (e) { gOtaErr = e; Update.abort(); otaResume(); return; }
    }
#if BOARD_CYD
    gOtaScan.feed(up.buf, up.currentSize);
#endif
    if (Update.write(up.buf, up.currentSize) != up.currentSize) {
      gOtaErr = String(TR(W_E_WRITE)) + Update.errorString();
      Update.abort();
      otaResume();
      return;
    }
    if (gOtaSize) otaScreen((int)((uint64_t)Update.progress() * 100 / gOtaSize), nullptr);
  } else if (up.status == UPLOAD_FILE_END) {
    if (gOtaErr.length()) return;
#if BOARD_CYD
    if (!gOtaScan.found) {                             // Datei passt nicht zum Namen bzw. ist kein Programm fuer das CYD
      Update.abort();
      gOtaErr = TR(gOtaApp == cyd::APP_GAMES ? W_E_NOT_GAMES : W_E_NOT_CLOCK);
      otaResume();
      return;
    }
#endif
    if (!Update.end(true)) { gOtaErr = String(TR(W_E_CHECK)) + Update.errorString(); otaResume(); }
    else {
#if BOARD_CYD
      if (gOtaApp == cyd::APP_GAMES) {                 // Spiele installiert: Uhr bleibt das Startprogramm
        cyd::bootSelf();
        dual::detect();
        otaResume();
        LOGF("RetroCYD installiert: %u Bytes\n", (unsigned)up.totalSize);
        return;
      }
#endif
      otaScreen(100, TR(K_OTA_DONE)); LOGF("Update ok: %u Bytes\n", (unsigned)up.totalSize);
    }
  } else if (up.status == UPLOAD_FILE_ABORTED) {
    Update.abort();
    gOtaErr = TR(W_E_ABORT);
    otaResume();
  }
}

static void handleUpdateDone() {
  if (!authOk()) return;
  if (gOtaErr.length() || !Update.isFinished()) {
    server.send(500, "text/plain; charset=utf-8", gOtaErr.length() ? gOtaErr : String(TR(W_E_INCOMP)));
    if (gOtaActive) otaResume();
    return;
  }
#if BOARD_CYD
  if (gOtaApp == cyd::APP_GAMES) { server.send(200, "text/plain; charset=utf-8", TR(W_G_INSTALLED)); return; }   // kein Neustart
#endif
  server.send(200, "text/plain", "OK");
  needReboot = true;
  rebootAt = millis() + 1500;
}

static void handleNotFound() {
  server.send(404, "text/plain; charset=utf-8", TR(W_NOT_FOUND));
}

static void webBegin() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/diag", HTTP_GET, []() {
    char b[420];
    snprintf(b, sizeof(b), "Schleifenluecke max %lu ms\nBildzeit max %lu us\nFreier Heap %u\n"
             "WLAN-Teil max %lu us\nWeb-Teil max %lu us\nZeichnen max %lu us\ndelay(2) max %lu us\nDesign gerade %d, im Browser gewaehlt %d, zuletzt gewechselt durch %c, Wechsel-Automatik %s\n",
             (unsigned long)gDiagGapLast, (unsigned long)gDiagFrameLast, (unsigned)ESP.getFreeHeap(),
             (unsigned long)gDiagSecLast[0], (unsigned long)gDiagSecLast[1], (unsigned long)gDiagSecLast[2], (unsigned long)gDiagSecLast[3], (int)gStyle, gDbgLook, gDbgSrc, gSet.autoOn ? "AN" : "aus");
    server.send(200, "text/plain", b);
  });
  server.on("/save", HTTP_POST, handleSave);
  server.on("/brightness", HTTP_POST, handleBrightness);
  server.on("/cal.json", HTTP_GET, []() {              // Kalender: Jahresuebersicht
    if (!authOk()) return;
    int y = server.arg("y").toInt();
    if (y < 2000 || y > 2100) { time_t n = time(nullptr); struct tm t; localtime_r(&n, &t); y = t.tm_year + 1900; }
    String j;
    cal::json(j, y);
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", j);
  });
  server.on("/calpop", HTTP_POST, []() {               // Einblendung testen (20 s)
    if (!authOk()) return;
    cal::popTest((uint8_t)constrain(server.arg("id").toInt(), 0, cal::CD_COUNT - 1));
    server.send(204);
  });
#if PIN_LED_R >= 0
  server.on("/ledprev", HTTP_POST, []() {             // LED-Vorschau (8 s, ohne Speichern)
    if (!authOk()) return;
    led::preview((uint8_t)constrain(server.arg("m").toInt(), 0, 6), strtoul(server.arg("c").c_str(), nullptr, 16) & 0xFFFFFF,
                 (uint8_t)constrain(server.arg("b").toInt(), 1, 100));
    server.send(204);
  });
#endif
  server.on("/scan", HTTP_GET, handleScan);
  server.on("/geo", HTTP_GET, handleGeo);
  server.on("/standby", HTTP_POST, handleStandby);
  server.on("/look", HTTP_POST, handleLook);
  server.on("/ticker", HTTP_POST, handleTicker);
  server.on("/reset", HTTP_POST, handleReset);
  server.on("/settime", HTTP_POST, handleSetTime);
  server.on("/beep", HTTP_POST, handleBeep);
#if SND_RICH
  server.on("/sndtest", HTTP_POST, []() {             // Klang anhoeren (ohne Speichern), v = Lautstaerke vom Regler
    if (!authOk()) return;
    if (!gAlarmRinging) {
      const String k = server.arg("k");
      const int i = server.arg("n").toInt();
      if (server.hasArg("v")) { bz::setVolume((uint8_t)constrain(server.arg("v").toInt(), 5, 100)); gSndTestVol = true; }
      if (k == "s") bz::stop();
      else if (k == "a") bz::alarmTest((uint8_t)constrain(i, 0, SND_AL_COUNT - 1));
      else if (k == "h") bz::chime((uint8_t)constrain(i, 0, SND_HR_COUNT - 1), 3, bz::PR_TEST);   // zaehlende Gongs: 3 Uhr
      else if (k == "c") bz::click();
      else if (k == "f") bz::fx((uint8_t)constrain(i, 0, FX_COUNT - 1), bz::PR_TEST);
    }
    server.send(204);
  });
#endif
  server.on("/alarmoff", HTTP_POST, handleAlarmOff);
  server.on("/ufo", HTTP_POST, handleUfo);
  server.on("/feed", HTTP_POST, handleFeed);
  server.on("/visit", HTTP_POST, handleVisit);
  server.on("/update", HTTP_POST, handleUpdateDone, handleUpdateUpload);
#if BOARD_CYD
  server.on("/games", HTTP_POST, []() {
    if (!authOk()) return;
    if (!dual::games()) { server.sendHeader("Location", "/"); server.send(303); return; }
    server.send(200, "text/html; charset=utf-8", String(F("<!doctype html><meta charset=utf-8><body style='font-family:sans-serif;background:#0d1117;color:#e6edf3;padding:20px'><h2>")) +
                TR(W_G_START) + "</h2><p>" + TR(W_G_STARTED) + "</p></body>");
    dual::gamesReq = true;
  });
  // Uhr-Update bei installierten Spielen: ueber RetroCYD (siehe fwUp im Browser)
  server.on("/fwprep", HTTP_GET, []() {
    if (!authOk()) return;
    const bool relay = dual::games() && cyd::appFromName(server.arg("name")) != cyd::APP_GAMES;
    server.send(200, "text/plain", relay ? "relay" : "direct");
  });
  server.on("/fwrelay", HTTP_POST, []() {
    if (!authOk()) return;
    if (!dual::games()) { server.send(400, "text/plain", "no"); return; }
    uint32_t tok = esp_random() | 1;
    Preferences p;
    if (p.begin("wuhr", false)) { p.putUInt("relay", tok); p.end(); }
    char b[12]; snprintf(b, sizeof(b), "%08lx", (unsigned long)tok);
    server.send(200, "text/plain", b);
    dual::relayReq = true;                 // in loop(): RetroCYD im Update-Modus starten
  });
  server.on("/tcal", HTTP_POST, []() {
    if (!authOk()) return;
    dual::calReq = true;
    server.sendHeader("Location", "/");
    server.send(303);
  });
#endif
  server.onNotFound(handleNotFound);
  server.begin();
}

static void webLoop(uint32_t now) {
  server.handleClient();
  if (!mdnsStarted && WiFi.status() == WL_CONNECTED) {
    if (MDNS.begin(gSet.host)) {
      MDNS.addService("http", "tcp", 80);
#if ARDUINO_OTA
      MDNS.enableArduino(3232, gSet.webPw[0] != 0);   // Netzwerk-Port in der Arduino IDE
#endif
      mdnsStarted = true;
    }
  }
  if (needReboot && (int32_t)(now - rebootAt) >= 0) ESP.restart();
}
