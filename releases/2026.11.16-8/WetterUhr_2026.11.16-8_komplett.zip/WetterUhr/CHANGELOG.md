# Aenderungen

Jede Version nennt die geaenderten Dateien. Fuer ein Update genuegt es, genau diese Dateien im Sketch-Ordner
zu ersetzen (neue hinzufuegen, entfernte loeschen), die Binaerdatei zu exportieren und per WLAN einzuspielen
(README, "Update ueber WLAN"). Die installierte Version steht im Browser unter Status > Firmware.

## 2026.11.16-8 - Korrektur: Task-Watchdog beim Flugradar

- Gemeldet: Neustart "Task-Watchdog", Absturz-Spur "Netz: Flugradar", kurz nach "Radar: HTTP -11" (Zeitlimit beim
  Lesen). Beim Warten auf Daten dreht die HTTP-Bibliothek bis zu 8 s in einer Schleife ohne Pause. Seit
  2026.11.16-3 lief der gemeinsame Netz-Task mit Prioritaet 1 auf Kern 0 und hungerte dabei den Leerlauf-Task aus -
  nach 5 s schlug der Task-Watchdog zu. Jetzt Prioritaet 0 wie frueher beim Radar-Task.

Geaenderte Dateien: `WetterUhr.ino`, `config.h`, `CHANGELOG.md`

## 2026.11.16-7 - Wetter neben dem Flugradar, ISS-Aussetzer, Selbstheilung

Aus dem Protokoll vom Geraet:
- Waehrend das Flugradar lief, scheiterte der Wetterabruf jede Minute mit "TLS -32512 SSL - Memory allocation
  failed": die offene Radar-Verbindung belegt rund 40 KB. Jetzt wird sie vor jedem Wetter- und Ferienabruf
  geschlossen (beide laufen im selben Netz-Task) und danach neu aufgebaut.
- Die Selbstheilung loeste aus, obwohl 14 s vorher ein Abruf geklappt hatte: Rechenfehler, wenn der Netz-Task den
  Zeitstempel nach dem Zeitpunkt der Hauptschleife setzte (Unterlauf). Behoben.
- ISS-Tracker: Der Dienst open-notify faellt oft kurz aus; bisher alle 5 s ein neuer Versuch und eine Zeile
  "ISS: Fehler". Jetzt nach Fehlern seltener (10 s, 20 s, 40 s, dann jede Minute), im Protokoll nur der erste
  Fehler mit HTTP-Code und "wieder ok". Bei Aussetzern bis 2 Minuten rechnet die Anzeige die Bahn weiter.

Geaenderte Dateien: `WetterUhr.ino`, `cal.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16-6 - Wetterabruf: Speicher fuer die verschluesselte Verbindung freimachen

- Protokoll vom Geraet: "Wetter: HTTP -1 (connection refused)", DNS in Ordnung, kleinster freier Speicher 40 Bytes.
  Der verschluesselte Abruf (TLS) braucht kurzzeitig rund 60-70 KB; seit 2026.11.16 war der Puffer der feinen
  Schrift (38 KB) dauerhaft belegt - damit reichte der Speicher nie mehr und das Wetter kam nicht.
- Jetzt gibt die Anzeige den Puffer der feinen Schrift fuer die Dauer eines TLS-Abrufs frei (Wetter, Schulferien,
  Ortssuche) und holt ihn danach wieder; die Schrift ist dabei 1-2 Sekunden grob. Beim Start wird er nicht mehr
  vorab belegt.
- Flugradar: feine Schrift aus (die offene TLS-Verbindung braucht den Speicher dauerhaft).
- Protokoll: genauer TLS-Fehler beim Wetterabruf; die Diag-Zeilen (alle 10 s) fuellen das Protokoll nicht mehr.

Geaenderte Dateien: `WetterUhr.ino`, `cal.h`, `webui.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16-5 - Wetterabruf: Fehler sichtbar, Namensaufloesung abgesichert

- Gemeldet: Es werden keine Wetterdaten geladen (Browser-Seite erreichbar, Uhrzeit falsch).
- Status > Wetter zeigt jetzt den letzten Fehler des Abrufs und den DNS-Server; das Protokoll (/log) zusaetzlich
  Speicher und DNS zum Zeitpunkt des Fehlers.
- Namensaufloesung: Nach dem Verbinden (und nach dem Abschalten des Notfall-Access-Points) werden Ersatz-DNS-Server
  eingetragen (1.1.1.1, 8.8.8.8); fehlt der DNS-Server des Routers, wird der Router selbst eingetragen.

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16-4 - Protokoll ueber Neustarts hinweg, Selbstheilung des Netzes

- Gemeldet: Uhr im Browser nicht erreichbar, Designs laufen weiter, Wetter "noch keine Daten"; erst ein Neustart hilft.
- Neues Protokoll im RTC-Speicher (uebersteht Neustart und Absturz): http://<uhr>/log zeigt die vorige und die
  aktuelle Sitzung - Start mit Grund, WLAN, NTP-Zeit, Fehler bei Wetter/Radar/ISS und alle 5 Minuten den Zustand
  (Speicher, WLAN, Uhrzeit, Wetter, letzter erfolgreicher Abruf, Anzahl Browser-Anfragen).
- Selbstheilung: Gilt das WLAN als verbunden, klappt aber 20 Minuten lang kein einziger Abruf (Wetter, Radar, ISS,
  Zeit), verbindet die Uhr das WLAN neu.
- Status: "Absturz-Spur" wird immer angezeigt (auch "kein Absturz"), mit Link zum Protokoll.
- Radar- und ISS-Abrufe schreiben nur noch Fehler ins Protokoll (sonst alle paar Sekunden eine Zeile).

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `lang_web.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16-3 - Mehr freier Speicher, Absturz-Spur im Status

- Wetter, Kalender, Flugradar und ISS holen ihre Daten jetzt in einem gemeinsamen Netz-Task (Kern 0) statt in drei
  Tasks mit zusammen 30 KB Stack. Die Abrufe liefen ohnehin nacheinander. Spart rund 18 KB Arbeitsspeicher
  (gemeldet: nur noch 53 KB frei, 32 KB am Stueck, Absturz beim ISS-Tracker).
- Absturz-Spur: Was gerade lief (Hauptschleife: Zeichnen mit Design-Nummer, Browser-Seite, Ton ...; Netz: Wetter,
  Radar, ISS ...), der kleinste freie Speicher und die Laufzeit werden im RTC-Speicher mitgeschrieben und nach
  einem Absturz unter Status > "Absturz-Spur" angezeigt.
- Ton-Task wieder mit 3 KB Stack.

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `lang_web.h`, `sfx_core.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16-2 - Browser-Seite auch bei Flugradar und ISS-Tracker erreichbar

- Flugradar und ISS-Tracker holen staendig Daten aus dem Internet; das Radar haelt dazu eine TLS-Verbindung offen
  (rund 40 KB) und braucht beim Auswerten weiteren Speicher. Kam dann eine Browser-Anfrage, fehlte dem Netz der
  Speicher: die Seite kam nur tropfenweise an, die Uhr stand bis zu einer Minute still.
- Jetzt: Solange der Browser die Uhr benutzt (6 s nach jeder Anfrage), pausieren Radar-, ISS- und Wetterabruf,
  und die offene Radar-Verbindung wird geschlossen. Danach laeuft alles normal weiter.

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `config.h`, `CHANGELOG.md`

## 2026.11.16 - Uhr bleibt nach langer Laufzeit im Browser erreichbar

- Ursache (sehr wahrscheinlich): Bei jedem Designwechsel wurden die Bildpuffer der Designs (19 KB, mit feiner Schrift
  zusaetzlich 38 KB) freigegeben und neu geholt, dazwischen TLS-Abrufe (Wetter, Radar). Mit der Zeit zerstueckelte
  der Speicher; nach Stunden fehlte ein grosser Block fuer Netz und Browser-Seite.
  Jetzt werden die Puffer einmal beim Start (vor dem WLAN) geholt und behalten. Auch der Puffer der Laufschrift
  bleibt fest (960 x 8).
- Browser-Seite: Haengt die Verbindung, wird sofort abgebrochen (vorher wartete jedes der rund 15 Stuecke bis zu
  10 s - die Uhr stand dann fast eine Minute still).
- Notbremse: Bleibt der groesste freie Speicherblock 10 Minuten unter 16 KB, startet die Uhr in einem ruhigen Moment
  neu (nicht waehrend der Wecker klingelt). Status zeigt dann "Software (Neustart)".

Geaenderte Dateien: `faces.h`, `ticker.h`, `webui.h`, `WetterUhr.ino`, `config.h`, `CHANGELOG.md`

## 2026.11.13-4 - Keine Stoergeraeusche mehr im Lautsprecher (CYD)

- Hintergrundbeleuchtung (PWM 2 kHz) und RGB-LED (5 kHz) wurden mit hoerbaren Frequenzen gedimmt. Der Strom
  dafuer koppelt in den Lautsprecher-Verstaerker ein: dauerndes Pfeifen/Brummen, sobald ein Lautsprecher steckt
  und die Helligkeit unter 100 % liegt oder die LED leuchtet. Jetzt beide mit 25 kHz (unhoerbar).
- RetroCYD 4.0.3: RGB-LED ebenfalls mit 25 kHz (die Hintergrundbeleuchtung lief dort schon mit 44 kHz).

Geaenderte Dateien: `config.h`, `led.h`, `CHANGELOG.md`

## 2026.11.13-4 - Weniger Stoergeraeusche im Lautsprecher (CYD)

- In Ruhe wird der Lautsprecher-Ausgang (GPIO 26) jetzt abgeschaltet (hochohmig mit schwachem Pull-down) statt
  aktiv auf 0 V gehalten. Ein aktiv getriebener Pin koppelt Stoerungen von WLAN und Display in den Verstaerker -
  das war als dauerndes Brummen/Zirpen zu hoeren. Beim naechsten Klang wird er wieder eingeschaltet (kein Knacken,
  gleiche Spannung).
- Abschaltbar unter "Summer & Wecker" (Lautsprecher-Ausgang in Ruhe abschalten), zum Vergleichen.
- RetroCYD 4.0.3 mit derselben Aenderung.

Geaenderte Dateien: `sfx_core.h`, `buzzer.h`, `webui.h`, `lang_web.h`, `WetterUhr.ino`, `config.h`, `CHANGELOG.md`

## 2026.11.13-3 - Browser-Seite bleibt erreichbar (Speicher)

- Die Browser-Seite wird im neuen Ton-Bereich in kleinen Stuecken gesendet (vorher ein grosser Block von mehreren
  KB, der bei knappem Speicher fehlschlagen konnte).
- Flugradar: Bei wenig freiem Speicher wird die dauerhaft offene TLS-Verbindung nach jedem Abruf geschlossen
  (gibt rund 40 KB frei), damit die Uhr im Browser erreichbar bleibt.
- Ton-Task wieder mit kleinerem Stack (2,5 KB reichen ohne Treiberaufrufe).
- Status: freier Speicher zusaetzlich mit dem groessten zusammenhaengenden Block.
- RetroCYD 4.0.2: gleiche Ton-Engine (kleinerer Stack).

Geaenderte Dateien: `webui.h`, `WetterUhr.ino`, `sfx_core.h`, `config.h`, `CHANGELOG.md`

## 2026.11.13-2 - Korrektur: Absturz und Knacken beim Abspielen von Klaengen (CYD)

- Die Tonhoehe wurde bisher mit `ledcChangeFrequency` umgestellt. Das konfiguriert den LEDC-Zeitgeber jedes Mal
  komplett neu und setzt ihn zurueck - bei Gleittoenen und Rauschen bis zu 1000-mal pro Sekunde. Folge: Knacken
  und (sehr wahrscheinlich) die Abstuerze, auch bei Klaengen, die ein Wetterwechsel oder das UFO ausloest.
  Jetzt wird nur noch der Teiler des eigenen Zeitgebers im Register umgestellt (kein Treiberaufruf, kein Reset).
- Ton-Task mit mehr Stack (4 KB) und niedrigerem Vorrang.
- Hoechstens 35 % Tastverhaeltnis: weniger Spitzenstrom fuer den Verstaerker (kaum leiser).
- Status: neue Zeile "Letzter Neustart" mit dem Grund (z. B. PANIC = Absturz, BROWNOUT = Spannungseinbruch)
  und Laufzeit - hilft bei der Fehlersuche.
- RetroCYD 4.0.1 mit derselben Ton-Korrektur.

Geaenderte Dateien: `sfx_core.h`, `webui.h`, `lang_web.h`, `config.h`, `CHANGELOG.md`

## 2026.11.13 - Klaenge fuer den CYD-Lautsprecher, mit Test im Browser

- CYD mit Lautsprecher an "SPEAK": neue Ton-Engine (`sfx_core.h`) mit Melodien, Gleittoenen, Rauschen und
  Ausklingen; spielt in einer eigenen kleinen Task, damit Melodien auch beim Zeichnen sauber bleiben.
- **Lautstaerke** einstellbar, **Weckton** waehlbar (9 Klaenge), **Stundengong** waehlbar (6, Kuckuck und
  Glockenschlag zaehlen die Stunde).
- **Klang-Effekte**: Feiertags-Einblendung mit passender Melodie, Silvester-Countdown und Feuerwerk, UFO im
  Flugradar, Designwechsel, Wetterwechsel (Regen, Schnee, Gewitter). Einzeln abschaltbar.
- Browser > "Summer & Wecker": jeder Klang mit Knopf zum Anhoeren (Reglerstellung, ohne Speichern) und "Klang stoppen".
- ESP32-C3 mit aktivem Summer: unveraendert.
- RetroCYD 4.0: Spiel-Sounds in allen 20 Spielen (siehe RetroCYD).

Geaenderte Dateien: `buzzer.h`, `sfx_core.h` (neu), `settings.h`, `webui.h`, `lang_web.h`, `WetterUhr.ino`,
`dualboot.h`, `face_radar.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.11-5 - Korrektur: Drehung um 180 Grad beim ESP32-C3

- Seit 2026.11.08 (Display-Anpassung) waren beim ESP32-C3 mit 2,0-Zoll-Display "Normal" und "180 Grad gedreht"
  vertauscht: das Bild stand bei "Normal" auf dem Kopf, die Einstellung schien nicht zu wirken. Jetzt wieder
  wie bis 2026.11.07. Wer zum Ausgleich "180 Grad" gewaehlt hatte, stellt wieder auf "Normal". CYD unveraendert.

Geaenderte Dateien: `board.h`, `config.h`, `CHANGELOG.md`

## 2026.11.11-4 - Korrektur: automatischer Design-Wechsel blieb stehen

- An Feier- und besonderen Tagen (z. B. 11.11.) setzte jede Feiertags-Einblendung (alle 15 min) das Design auf das
  gespeicherte zurueck und startete den Wechsel-Timer neu - der automatische Wechsel kam so nie weiter.
  Jetzt haelt die Einblendung Design und Timer nur an; danach geht es mit dem vorherigen Design weiter.
- Tippen auf das Display waehrend der Einblendung beendet sie (statt das gespeicherte Design zu aendern).
- Auswahl im Browser waehrend der Einblendung gilt danach.

Geaenderte Dateien: `WetterUhr.ino`, `config.h`, `CHANGELOG.md`

## 2026.11.11-3 - Korrektur: richtige Update-Datei wurde abgelehnt

- Fehler aus 2026.11.11-2 / RetroCYD 3.9 behoben: Eine korrekte `*_update.bin` wurde mit "Erstinstallations-Datei
  (mit Bootloader)" abgelehnt. Die Pruefung des Dateianfangs lief nicht nur beim ersten, sondern auch bei den
  folgenden Uebertragungs-Bloecken (das Update-Modul meldet erst nach 4 KB Fortschritt). Jetzt wird nur der
  allererste Block geprueft.
- RetroCYD 3.9.1 mit derselben Korrektur.

Geaenderte Dateien: `webui.h`, `config.h`, `CHANGELOG.md`

## 2026.11.11-2 - Firmware-Update: nur passende Dateien, richtiges Programm automatisch

- Der Browser prueft die gewaehlte Datei am **Inhalt** (nicht mehr am Namen), bevor etwas uebertragen wird:
  Erstinstallations-Dateien (mit Bootloader), Dateien fuer das andere Board (CYD / ESP32-C3), alte Versionen ohne
  Kennung und fremde Dateien werden mit Erklaerung abgelehnt.
- Uhr-Datei -> Uhr-Update (bei installierten Spielen automatisch ueber RetroCYD), RetroCYD-Datei -> wird neben der
  Uhr installiert, danach auf Wunsch die Spiele starten. Der Dateiname spielt keine Rolle mehr.
- Die Uhr prueft zusaetzlich selbst den ersten Block (Programm-Kennung, Chip) und am Ende die Programm-Kennung.
- RetroCYD 3.9: gleiche Pruefung; eine RetroCYD-Datei im RetroCYD-Browser startet die Uhr und wird dort eingespielt,
  danach starten die Spiele wieder.

Geaenderte Dateien: `webui.h`, `lang_web.h`, `config.h`, `CHANGELOG.md`

## 2026.11.11 - Kalender mit Feiertagen, besonderen Tagen und Schulferien

- Neuer Reiter **Kalender** im Browser: Bundesland waehlen, gesetzliche Feiertage, besondere Tage und Schulferien
  einzeln ein-/ausschalten, Jahresuebersicht (12 Monatsblaetter und Liste), Einblendungen zum Ansehen.
- Gesetzliche Feiertage je Bundesland (auch Fronleichnam, Reformationstag, Buss- und Bettag, Frauentag,
  Weltkindertag, Mariae Himmelfahrt, Oster-/Pfingstsonntag in Brandenburg) werden in der Uhr berechnet.
- Besondere Tage: Valentinstag, Weiberfastnacht, Rosenmontag, Faschingsdienstag, Muttertag, Vatertag, Erntedank,
  Halloween, Sankt Martin, Nikolaus, 1.-4. Advent, Heiligabend, Silvester; dazu Ferienbeginn und letzter Schultag.
- Schulferien kommen von openholidaysapi.org (frei, ohne Schluessel), werden gespeichert und woechentlich erneuert.
- Neues klassisches Design 28 **Kalender**: Monatsblatt (Feiertage rot, besondere Tage mit Punkt, Ferien blau),
  daneben heute / demnaechst / Schulferien mit Countdown und das Wetter.
- Am Feier- oder besonderen Tag erscheint regelmaessig (Standard alle 15 Minuten, 7-22 Uhr, nicht im Dimm-Fenster)
  fuer 20 Sekunden ein eigenes lustiges, animiertes Bild mit Uhrzeit (37 Szenen) und ein passender Spruch als
  Laufschrift.
- Laufschrift mit Countdown ("Morgen ist ...", "Noch 12 Tage bis zu den Herbstferien", "Herbstferien: noch 4 Tage
  frei!"), Standard alle 30 Minuten.

Geaenderte Dateien: `cal.h`, `cal_text.h`, `face_party.h` (neu), `faces.h`, `WetterUhr.ino`, `settings.h`, `webui.h`,
`lang_web.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.10-5 - Fortschrittsbalken beim Update

- Browser: Firmware-Update zeigt jetzt neben der Prozentzahl einen Balken.
- RetroCYD 3.8.1: Im Update-Modus fuer die Uhr ("UHR-UPDATE") blieb der Balken am Display leer und ohne Prozent,
  weil die Fortschrittsanzeige in diesem Modus nicht angemeldet war. Behoben.

Geaenderte Dateien: `webui.h`, `config.h`, `CHANGELOG.md`

## 2026.11.10-4 - Menue ohne Reste des Uhrbilds

- CYD: Beim Oeffnen des Halte-Menues (Spiele / Standby / Zurueck) wurde im selben Durchlauf noch einmal das Uhrbild
  aktualisiert - geaenderte Teile (Sekunden, Animationen) lagen dann ueber dem Menue. Jetzt wird in diesem Moment
  nicht mehr gezeichnet.

Geaenderte Dateien: `WetterUhr.ino`, `config.h`, `CHANGELOG.md`

## 2026.11.10-3 - RGB-LED des CYD steuern

- Browser: Helligkeit > RGB-LED (nur CYD). Modi: aus, feste Farbe, Wetter-Farbe, Temperatur-Farbe, Farbwechsel,
  Atmen, Sekundenpuls. Farbe, Helligkeit, "wann" (immer / nur nachts als Nachtlicht / nachts aus).
- Hinweise blinken zusaetzlich (einzeln abschaltbar): Wecker rot (wie bisher), Update blau, kein WLAN orange,
  Gewitter violett, Frost eisblau.
- Aenderungen sind sofort 8 Sekunden lang als Vorschau zu sehen (neue Adresse /ledprev).
- Im Standby bleibt die LED aus (ausser Wecker und Update).
- RetroCYD 3.8: LED-Effekte in den Spielen (siehe RetroCYD.ino).

Geaenderte Dateien: `led.h` (neu), `WetterUhr.ino`, `settings.h`, `webui.h`, `lang_web.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.10 - Ortssuche fuer den Standort

- Reiter "Wetter": neues Feld "Ort suchen" ueber Breiten- und Laengengrad. Ort oder Postleitzahl eingeben, Enter oder
  "Suchen", Treffer (Name, PLZ, Kreis, Land, Koordinaten, Hoehe) antippen - die Koordinaten werden eingetragen.
- Suche ueber die Ortssuche von Open-Meteo (gleicher Dienst wie das Wetter, ohne Schluessel), in der eingestellten
  Sprache. Der Browser fragt direkt; klappt das nicht, fragt die Uhr selbst (neue Adresse /geo).
- Koordinaten koennen weiterhin von Hand eingetragen werden.

Geaenderte Dateien: `webui.h`, `lang_web.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.09-6 - Feinere Darstellung, Grossanzeige (fuer das CYD 2,8 Zoll)

- Themen-Designs: Kanten glaetten (Scale2x beim Vergroessern) und Schrift in voller Aufloesung (Texte, Datum, Zahlen
  fein darueber gezeichnet). Im Browser unter Anzeige > Darstellung; CYD: an, ESP32-C3: aus.
- Neues klassisches Design 27 "Grossanzeige": Uhrzeit als 7-Segment ueber die ganze Breite, Sekundenbalken,
  grosse Temperatur mit Wettersymbol, Datum und Wochentag - aus der Ferne lesbar.
- RetroCYD 3.6: Spiele per Touch spielbar (ohne Controller), siehe RetroCYD.ino.

Geaenderte Dateien: `faces_hires.h` (neu), `font5x7.h` (neu), `faces.h`, `faces_core.h`, `WetterUhr.ino`, `webui.h`,
`settings.h`, `config.h`, `lang_web.h`, `README.md`, `CHANGELOG.md`

## 2026.11.09-5 - Uhr-Update direkt im Browser der Uhr (CYD mit Spielen)

- Ein Uhr-Update laesst sich jetzt auch bei installierten Spielen ganz normal unter System > Firmware-Update einspielen.
  Die Uhr startet dafuer kurz RetroCYD im Update-Modus (WLAN der Uhr, gleiche IP, Einmal-Schluessel), die Seite
  schickt die Datei automatisch dorthin, RetroCYD schreibt die neue Uhr und startet sie. Kein Umweg ueber das
  RetroCYD-Setup mehr.
- RetroCYD 3.5: Update-Modus fuer die Uhr (ohne Bluetooth/Spiele, nach 3 Minuten ohne Datei zurueck zur Uhr).
- Einmalig: Diese Version selbst muss noch ueber das RetroCYD-Setup (oder per USB) auf die Uhr, weil die alte Uhr den
  neuen Ablauf noch nicht kennt.

Geaenderte Dateien: `webui.h`, `dualboot.h`, `lang_web.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.09-4 - WLAN bleibt beim Wechsel Uhr/Spiele erhalten (CYD)

- Uhr und RetroCYD teilen sich den kleinen Einstellungsspeicher (NVS, 20 KB). Wird er voll oder unlesbar, loescht der
  Start ihn komplett - dann waren WLAN und Einstellungen weg. Neu: Die Uhr sichert WLAN, Einstellungen und
  Touch-Kalibrierung zusaetzlich ausserhalb des NVS (ungenutzter Bereich "spiffs") und stellt sie beim naechsten Start
  selbst wieder her.
- Der WLAN-Treiber schreibt nichts mehr ins NVS (`WiFi.persistent(false)` vor dem ersten WLAN-Aufruf); das entlastet
  den gemeinsamen Speicher.
- Status zeigt die Belegung des Einstellungsspeichers und ob aus der Sicherung wiederhergestellt wurde.
- RetroCYD 3.4: nutzt im Setup automatisch das WLAN der Uhr (auch aus der Sicherung), wenn das eigene fehlt oder nicht
  erreichbar ist.

Geaenderte Dateien: `cyd_shared.h`, `settings.h`, `WetterUhr.ino`, `webui.h`, `lang_web.h`, `config.h`, `CHANGELOG.md`

## 2026.11.09-3 - Sechs Designs entfernt

- Entfernt: Labyrinth, Zahnrad-Werk, Blockwelt, Familie, Weihnachtself, Squishy Dumpling (jetzt 27 Designs:
  2 klassische + 25 Themen). Die Nummern ab 4 sind nachgerueckt; gespeicherte Auswahl und Wechsel-Liste werden beim
  ersten Start umgerechnet, ein entferntes Design wird durch ein aehnliches ersetzt.
- Weihnachten kommt im Feiertags-Wechsel jetzt allein (ohne Elf). Kategorie "Heimat & Familie" entfaellt.
- Programm rund 35 KB kleiner.

Geaenderte Dateien: `faces.h`, `config.h`, `settings.h`, `webui.h`, `lang.h`, `lang_web.h`, `WetterUhr.ino`, `README.md`,
`CHANGELOG.md`; entfernt: `face_maze.h`, `face_works.h`, `face_voxel.h`, `face_family.h`, `face_elf.h`, `face_dumpling.h`

## 2026.11.09 - Spiele (RetroCYD) als zweites Programm auf dem CYD

- Nur CYD: RetroCYD 3.2 kann als zweites Programm neben der Uhr liegen. Beim Einschalten Auswahl "Uhr" oder "Spiele"
  am Touchscreen (sonst nach 6 s die Uhr), langes Halten oeffnet ein Menue mit "Spiele", "Standby", "Zurueck".
- Touchscreen mit Koordinaten und Kalibrierung (3 Kreuze; beim ersten Start mit Spielen automatisch, sonst im Browser).
- Browser: System > Spiele (RetroCYD) mit "Spiele starten" und "Touch kalibrieren"; Status zeigt RetroCYD.
- Firmware-Update erkennt RetroCYD-Dateien und installiert sie neben der Uhr; ein Uhr-Update, das die Spiele
  ueberschreiben wuerde, wird abgelehnt (dann ueber RetroCYD einspielen). Inhalt der Datei wird geprueft.
- Neue Datei fuer die Erstinstallation mit Uhr und Spielen: `..._CYD_mitSpielen_erstinstallation.bin`.
- ESP32-C3: unveraendert (nur neue Texte).

Geaenderte Dateien: `cyd_shared.h` (neu), `dualboot.h` (neu), `board.h`, `WetterUhr.ino`, `webui.h`, `lang.h`,
`lang_web.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.11.08 - Display-Anpassung im Browser

- Neu unter *System > Display-Anpassung*: Display-Controller (automatisch, ILI9341, ST7789), Achsen tauschen,
  links/rechts und oben/unten spiegeln, Rot und Blau tauschen, Farben invertieren. Wirkt sofort nach "Speichern".
- CYD: Der Controller wird beim Start automatisch erkannt (ILI9341 oder ST7789); Status zeigt Controller und Kennung.
- Die Compile-Optionen `CYD_ST7789` und `TFT_FORCE_INVERT` entfallen (jetzt im Browser).

Geaenderte Dateien: `board.h`, `config.h`, `settings.h`, `WetterUhr.ino`, `webui.h`, `lang_web.h`, `README.md`, `CHANGELOG.md`

## 2026.11.07 - CYD 2,8 Zoll

- Laeuft jetzt auch auf dem **CYD 2,8 Zoll** (ESP32-2432S028R, "Cheap Yellow Display"): ILI9341 320 x 240,
  Touchscreen statt Touch-Taster, Ton ueber den Lautsprecher-Anschluss, echte Helligkeitsregelung ueber das Backlight,
  RGB-LED blinkt rot beim Wecken. Gleicher Quellcode wie fuer den ESP32-C3; das Board wird automatisch erkannt.
- Option `CYD_ST7789` fuer die CYD-Variante mit ST7789.
- Firmware-Update ueber WLAN prueft, ob die Datei zum Board passt.
- Status-Seite zeigt die Hardware.
- Release-Dateien fuer beide Boards (CYD-Dateien mit `CYD` im Namen).

Geaenderte Dateien: `board.h` (neu), `config.h`, `WetterUhr.ino`, `webui.h`, `buzzer.h`, `lang_web.h`, `faces.h`,
`README.md`, `CHANGELOG.md`

## 2026.10.31-3 - Sprachen

- Sprache waehlbar unter Anzeige > Darstellung: Deutsch, English, Francais, Espanol, Italiano.
- Uebersetzt sind das Display (alle Designs, Wochentage, Datum, Wettertexte, Feiertags-Gruesse, Badminton-Ansagen,
  Flugradar, ISS, Sonne und Mond, Update-Anzeige) und die komplette Browser-Seite inkl. Design-Namen.
- Datum ausserhalb von Deutsch als `31/10`; lange Ueberschriften werden automatisch kleiner, damit sie passen.
- ISS-Tracker: "Lade ISS-Daten" ueberdeckt nicht mehr das Datum.

Geaenderte Dateien: `lang.h` (neu), `lang_web.h` (neu), `WetterUhr.ino`, `webui.h`, `settings.h`, `config.h`, `icons.h`,
`faces_core.h`, `faces_fx.h`, `pet.h`, alle `face_*.h` mit Text oder Datum, `README.md`, `CHANGELOG.md`

## 2026.10.31-2 - Weihnachtself im Feiertags-Wechsel

- Der Weihnachtself kommt zusammen mit Weihnachten vom 14. bis 26.12. automatisch in den Design-Wechsel.

Geaenderte Dateien: `WetterUhr.ino`, `faces.h`, `webui.h`, `config.h`, `README.md`, `CHANGELOG.md`

## 2026.10.31 - Feiertage automatisch im Design-Wechsel

- Weihnachten, Silvester, Valentinstag, Halloween und Ostern kommen jeweils 10 Tage vor dem Termin automatisch in den
  Design-Wechsel und fallen nach dem Fest wieder heraus (Weihnachten 14.-26.12., Silvester 21.12.-1.1.,
  Valentinstag 4.-14.2., Halloween 21.-31.10., Ostern 10 Tage vor Ostersonntag bis Ostermontag).
- Die eigene Liste bleibt unveraendert; abschaltbar unter Anzeige > Extras. Die Status-Seite zeigt, welche
  Feiertags-Designs gerade dazugekommen sind.

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `settings.h`, `config.h`, `faces.h`, `README.md`, `CHANGELOG.md`

## 2026.10.30 - Update ueber WLAN

- Firmware-Update im Browser (System > Firmware-Update ueber WLAN): Fortschritt im Browser und auf dem Display,
  die Datei wird geprueft, Neustart nur bei Erfolg, sonst laeuft die alte Firmware weiter.
- Update direkt aus der Arduino IDE ueber den Netzwerk-Port (Passwort = Web-Passwort), abschaltbar mit `ARDUINO_OTA 0`.
- Firmware-Version und Bauzeit unter Status und System (`FW_VERSION` in `config.h`).
- Hinweis auf der Web-Seite, wenn das Partitionsschema kein Update erlaubt.
- Empfohlenes Partitionsschema jetzt *Minimal SPIFFS (1.9MB APP with OTA)*.

Geaenderte Dateien: `WetterUhr.ino`, `webui.h`, `config.h`, `README.md`, `CHANGELOG.md` (neu)

**Einmalig:** Wer bisher *Huge APP (No OTA)* verwendet, laedt diese Version einmal per USB mit dem neuen
Partitionsschema hoch. Danach gehen alle weiteren Updates per WLAN.

## 2026.10.29 - Aquarium, Badminton-Spielstand

- Aquarium neu gestaltet (Korallenriff, neue Fischarten, Schwarm, Qualle), Besuch von Seeschlange oder U-Boot,
  Knoepfe "Fische fuettern" und "Besuch" unter Anzeige > Extras.
- Badminton: spannenderer Spielverlauf ueber drei Saetze; Spielstand bleibt bei Designwechsel und Neustart erhalten.

Dateien: `face_aqua.h`, `face_badminton.h`, `faces.h`, `webui.h`, `README.md`

## 2026.10.28

- Squishy Dumpling, Feiertags-Designs (Weihnachten, Elf, Halloween, Ostern, Valentinstag, Silvester), UFO im
  Flugradar, Weihnachtsschlitten im ISS-Tracker, Silvester-Automatik; Designs entfernt und Nummern umgerechnet;
  Nachtmodus mit Testbild, manuelle Uhrzeit, Summer und Wecker, Touch-Taster.
