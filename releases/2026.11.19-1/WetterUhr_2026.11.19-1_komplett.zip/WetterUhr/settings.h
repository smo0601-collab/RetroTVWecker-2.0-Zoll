#pragma once
/*
  Einstellungen, die ueber die Browser-Seite geaendert und dauerhaft im
  Flash (NVS, Namespace "wuhr") gespeichert werden.
*/
#include <Arduino.h>
#include <Preferences.h>
#include "config.h"
#if BOARD_CYD
#include "cyd_shared.h"
#endif
#include "lang.h"

struct Settings {
  char     ssid[33];
  char     pass[65];
  char     tz[64];
  char     ntp[48];
  bool     ntpOn;      // Uhrzeit per NTP (sonst nur manuell)
  char     host[24];
  char     webPw[33];
  float    lat, lon;
  uint8_t  bright;     // 5..100
  bool     seconds;
  uint8_t  rotation;   // 1 oder 3
  uint16_t updMin;     // Wetter-Intervall in Minuten
  uint8_t  radarKm;    // Flugradar-Radius in km (5..100)
  uint8_t  clockStyle; // 0..CLOCK_STYLE_COUNT-1
  uint8_t  accent;     // 0..8
  bool     dimOn;      // Zeitplan-Dimmung aktiv
  uint16_t dimStart;   // Minuten seit Mitternacht
  uint16_t dimEnd;
  uint8_t  dimLevel;   // 5..100 %
  bool     dimTv;      // im Dimm-Zeitfenster (Nachtmodus) das Testbild zeigen
  bool     autoOn;     // Designs automatisch wechseln
  bool     autoRnd;    // zufaellige Reihenfolge
  uint64_t autoMask;   // Bit n = Design n nimmt am Wechsel teil
  uint32_t autoSec;    // Intervall in Sekunden
  bool     tickOn;     // Laufschrift aktiv
  bool     tickLoop;   // Dauerschleife (sonst einmalig)
  bool     tickBg;     // Hintergrundband
  uint8_t  tickPos;    // 0 oben, 1 Mitte, 2 unten
  uint8_t  tickBig;    // 0 mittel, 1 gross
  uint8_t  tickColor;  // 0..8 Akzentfarben, 9 weiss
  uint8_t  tickSpeed;  // 1..10
  uint16_t tickPause;  // Sekunden zwischen Durchlaeufen (Schleife)
  char     tick[161];  // Text (UTF-8)
  bool     bzHour;     // Summer: Stundensignal
  bool     bzQuiet;    // Summer: kein Stundensignal im Dimm-Zeitfenster
  bool     bzTouch;    // Summer: Klick bei Touch
  uint8_t  sndVol;     // Lautsprecher (CYD): Lautstaerke 5..100 %
  uint8_t  alTone;     // Lautsprecher (CYD): Weckton (buzzer.h, ALARMS)
  uint8_t  hrTone;     // Lautsprecher (CYD): Stundengong (buzzer.h, HOURS)
  uint8_t  sndFx;      // Lautsprecher (CYD): Effekte (FXB_* in buzzer.h)
  bool     alOn;       // Wecker aktiv
  uint16_t alTime;     // Weckzeit, Minuten seit Mitternacht
  uint8_t  alDays;     // Bit 0 = Mo ... Bit 6 = So
  bool     ufoOn;      // Flugradar: UFO-Sichtungen
  uint8_t  sleigh;     // ISS-Tracker: 0 ISS, 1 Schlitten, 2 Schlitten im Dezember (1.-26.)
  bool     nyeAuto;    // Silvester-Automatik
  bool     holAuto;    // Feiertags-Designs vor dem Termin automatisch im Wechsel
  uint8_t  fine;       // Themen-Designs: Bit 0 Kanten glaetten, Bit 1 feine Schrift
  uint8_t  panel;      // Display-Controller: 0 automatisch, 1 ILI9341, 2 ST7789
  uint8_t  pflags;     // Display-Anpassung (board.h: PF_SWAPXY, PF_MIRX, PF_MIRY, PF_BGR, PF_INV)
  uint8_t  lang;       // Sprache: 0 Deutsch, 1 Englisch, 2 Franzoesisch, 3 Spanisch, 4 Italienisch
  uint8_t  ledMode;    // RGB-LED (CYD): 0 aus, 1 Farbe, 2 Wetter, 3 Temperatur, 4 Farbwechsel, 5 Atmen, 6 Sekundenpuls
  uint32_t ledCol;     // feste Farbe 0xRRGGBB
  uint8_t  ledBri;     // 1..100 %
  uint8_t  ledTime;    // 0 immer, 1 nur nachts, 2 nachts aus
  uint8_t  ledHint;    // Bit 0 Wecker, 1 kein WLAN, 2 Update, 3 Gewitter/Frost
  uint8_t  calBl;      // Kalender: Bundesland 0 = keins, 1..16 (cal.h BL_CODE)
  uint8_t  calFlags;   // Kalender: Bit 0 Feiertage, 1 besondere Tage, 2 Schulferien, 3 Einblendung, 4 Laufschrift
  uint8_t  calPop;     // Minuten zwischen den Einblendungen am Feiertag (5..60)
  uint8_t  calTick;    // Minuten zwischen den Kalender-Laufschriften (5..240)
  bool     dimOff;     // im Dimm-Zeitfenster das Display ganz ausschalten (statt dimmen)
};

static Settings    gSet;
static Preferences prefs;

// Design-Nummern, Version 2 (Oktober 2026): 8 klassische und 6 Themen-Designs entfernt, 6 neue angehaengt.
// Gespeicherte Auswahl und Wechsel-Liste aus Version 1 (40 Designs) werden beim ersten Start umgerechnet.
// Version 3 (November 2026): Labyrinth, Zahnrad-Werk, Blockwelt, Familie, Weihnachtself, Squishy Dumpling entfernt.
#define STYLE_VERSION 3
static const int8_t STYLE_V1_SEL[40]  = {1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 18, 23, 6, 19, 20, 20, 21, 22, 22, 23, 25, 24, 25};   // alte Nummer -> neue (aehnliches Design)
static const int8_t STYLE_V1_LIST[40] = {-1, -1, -1, -1, -1, -1, -1, 0, 1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, -1, -1, -1, 19, 20, -1, 21, -1, 22, 23, -1, 24, 25};   // alte Nummer -> neue, -1 = entfernt

static const int8_t STYLE_V2_SEL[33]  = {0, 1, 2, 3, 2, 4, 5, 6, 7, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 2, 16, 20, 21, 22, 22, 23, 24, 25, 26, 16};
static const int8_t STYLE_V2_LIST[33] = {0, 1, 2, 3, -1, 4, 5, 6, 7, -1, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, -1, -1, 20, 21, 22, -1, 23, 24, 25, 26, -1};

static void settingsSave();
static bool gSetRestored = false;   // CYD: Einstellungen kamen aus der Sicherung (NVS war leer)

static void settingsLoad() {
  prefs.begin("wuhr", true);   // nur lesen
  const bool nvsEmpty = !prefs.isKey("ssid");
  strlcpy(gSet.ssid,  prefs.getString("ssid",  DEFAULT_WIFI_SSID).c_str(), sizeof(gSet.ssid));
  strlcpy(gSet.pass,  prefs.getString("pass",  DEFAULT_WIFI_PASS).c_str(), sizeof(gSet.pass));
  strlcpy(gSet.tz,    prefs.getString("tz",    DEFAULT_TZ).c_str(),        sizeof(gSet.tz));
  strlcpy(gSet.ntp,   prefs.getString("ntp",   DEFAULT_NTP).c_str(),       sizeof(gSet.ntp));
  strlcpy(gSet.host,  prefs.getString("host",  DEFAULT_HOSTNAME).c_str(),  sizeof(gSet.host));
  strlcpy(gSet.webPw, prefs.getString("webpw", "").c_str(),                sizeof(gSet.webPw));
  gSet.lat      = prefs.getFloat("lat", DEFAULT_LAT);
  gSet.lon      = prefs.getFloat("lon", DEFAULT_LON);
  gSet.bright   = prefs.getUChar("bright", DEFAULT_BRIGHTNESS);
  gSet.seconds  = prefs.getBool("sec", DEFAULT_SECONDS != 0);
  gSet.rotation = prefs.getUChar("rot", DEFAULT_ROTATION);
  gSet.updMin   = prefs.getUShort("upd", DEFAULT_UPDATE_MIN);
  gSet.radarKm  = prefs.getUChar("rkm", DEFAULT_RADAR_KM);
  gSet.clockStyle = prefs.getUChar("cs", DEFAULT_CLOCK_STYLE);
  gSet.accent     = prefs.getUChar("acc", DEFAULT_ACCENT);
  gSet.dimOn      = prefs.getBool("dimon", DEFAULT_DIM_ENABLE != 0);
  gSet.dimStart   = prefs.getUShort("dims", DEFAULT_DIM_START);
  gSet.dimEnd     = prefs.getUShort("dime", DEFAULT_DIM_END);
  gSet.dimLevel   = prefs.getUChar("diml", DEFAULT_DIM_LEVEL);
  gSet.dimTv      = prefs.getBool("dimtv", DEFAULT_DIM_TESTCARD != 0);
  gSet.dimOff     = prefs.getBool("dimoff", false);
  gSet.autoOn   = prefs.getBool("auto", DEFAULT_AUTO_ON != 0);
  gSet.autoRnd  = prefs.getBool("arnd", false);
  gSet.autoMask = (uint64_t)prefs.getUInt("amask", DEFAULT_AUTO_MASK) | ((uint64_t)prefs.getUInt("amaskh", 0) << 32);
  gSet.autoSec  = prefs.getUInt("asec", DEFAULT_AUTO_SEC);
  gSet.tickOn    = prefs.getBool("tkon", false);
  gSet.tickLoop  = prefs.getBool("tkloop", false);
  gSet.tickBg    = prefs.getBool("tkbg", true);
  gSet.tickPos   = prefs.getUChar("tkpos", 2);
  gSet.tickBig   = prefs.getUChar("tkbig", 0);
  gSet.tickColor = prefs.getUChar("tkcol", 9);
  gSet.tickSpeed = prefs.getUChar("tkspd", 5);
  gSet.tickPause = prefs.getUShort("tkpause", 10);
  strlcpy(gSet.tick, prefs.getString("tk", DEFAULT_TICK_TEXT).c_str(), sizeof(gSet.tick));
  gSet.ntpOn   = prefs.getBool("ntpon", DEFAULT_NTP_ON != 0);
  gSet.bzHour  = prefs.getBool("bzhr", DEFAULT_HOUR_BEEP != 0);
  gSet.bzQuiet = prefs.getBool("bzq", DEFAULT_BEEP_QUIET != 0);
  gSet.bzTouch = prefs.getBool("bztc", DEFAULT_TOUCH_BEEP != 0);
  gSet.sndVol  = prefs.getUChar("svol", 50);
  if (gSet.sndVol < 5 || gSet.sndVol > 100) gSet.sndVol = 50;
  gSet.alTone  = prefs.getUChar("altn", 0);
  gSet.hrTone  = prefs.getUChar("hrtn", 0);
  gSet.sndFx   = prefs.getUChar("sfx", 0x17);      // Feiertag, Silvester, UFO, Wetter (nicht Designwechsel)
  gSet.alOn    = prefs.getBool("alon", DEFAULT_ALARM_ON != 0);
  gSet.alTime  = prefs.getUShort("alt", DEFAULT_ALARM_TIME);
  gSet.alDays  = prefs.getUChar("ald", DEFAULT_ALARM_DAYS);
  gSet.ufoOn   = prefs.getBool("ufo", DEFAULT_UFO != 0);
  gSet.sleigh  = prefs.getUChar("sled", DEFAULT_SLEIGH);
  gSet.nyeAuto = prefs.getBool("nyeauto", DEFAULT_NYE_AUTO != 0);
  gSet.holAuto = prefs.getBool("holauto", DEFAULT_HOL_AUTO != 0);
  gSet.fine    = prefs.getUChar("fine", DEFAULT_FINE) & 3;
  gSet.panel   = prefs.getUChar("panel", DEFAULT_PANEL);
  if (gSet.panel > 2) gSet.panel = 0;
  gSet.pflags  = prefs.getUChar("pflg", DEFAULT_PANEL_FLAGS) & 0x1F;
  gSet.ledMode = prefs.getUChar("ledm", 0);
  gSet.ledCol  = prefs.getUInt("ledc", 0xFF9030);
  gSet.ledBri  = prefs.getUChar("ledb", 30);
  gSet.ledTime = prefs.getUChar("ledt", 0);
  gSet.ledHint = prefs.getUChar("ledh", 0x05);   // Wecker und Update (wie bisher nur der Wecker)
  if (gSet.ledMode > 6) gSet.ledMode = 0;
  if (gSet.ledBri < 1 || gSet.ledBri > 100) gSet.ledBri = 30;
  if (gSet.ledTime > 2) gSet.ledTime = 0;
  gSet.ledCol &= 0xFFFFFF;
  gSet.calBl    = prefs.getUChar("calbl", 0);
  gSet.calFlags = prefs.getUChar("calf", 0x1F);
  gSet.calPop   = prefs.getUChar("calp", 15);
  gSet.calTick  = prefs.getUChar("calt", 30);
  if (gSet.calBl > 16) gSet.calBl = 0;
  if (gSet.calPop < 5 || gSet.calPop > 60) gSet.calPop = 15;
  if (gSet.calTick < 5) gSet.calTick = 30;
  gSet.lang    = prefs.getUChar("lang", DEFAULT_LANG);
  if (gSet.lang >= LANG_COUNT) gSet.lang = 0;
  gLang = gSet.lang;
  const uint8_t sver = prefs.isKey("cs") ? prefs.getUChar("sver", 1) : STYLE_VERSION;
  prefs.end();

  if (sver < 2) {                                  // Design-Nummern aus Version 1 umrechnen
    const uint8_t oldCs = gSet.clockStyle;
    gSet.clockStyle = (oldCs < 40) ? (uint8_t)STYLE_V1_SEL[oldCs] : 0;
    uint64_t m = 0;
    for (int i = 0; i < 40; i++)
      if ((gSet.autoMask >> i) & 1) { const int n = STYLE_V1_LIST[i]; if (n >= 0) m |= (1ULL << n); }
    gSet.autoMask = m;
  }
  if (sver < 3) {                                  // Version 2 -> 3: sechs Designs entfernt
    const uint8_t oldCs = gSet.clockStyle;
    gSet.clockStyle = (oldCs < 33) ? (uint8_t)STYLE_V2_SEL[oldCs] : 0;
    uint64_t m = 0;
    for (int i = 0; i < 33; i++)
      if ((gSet.autoMask >> i) & 1) { const int n = STYLE_V2_LIST[i]; if (n >= 0) m |= (1ULL << n); }
    gSet.autoMask = m;
  }

  // Plausibilitaet erzwingen (falls Flash-Inhalt unerwartet ist)
  if (gSet.bright < 5 || gSet.bright > 100) gSet.bright = 100;
  if (gSet.rotation != 1 && gSet.rotation != 3) gSet.rotation = 1;
  if (gSet.updMin < 5 || gSet.updMin > 120) gSet.updMin = DEFAULT_UPDATE_MIN;
  if (gSet.radarKm < 5 || gSet.radarKm > 100) gSet.radarKm = DEFAULT_RADAR_KM;
  if (!(gSet.lat >= -90.0f && gSet.lat <= 90.0f)) gSet.lat = DEFAULT_LAT;
  if (!(gSet.lon >= -180.0f && gSet.lon <= 180.0f)) gSet.lon = DEFAULT_LON;
  if (gSet.clockStyle >= CLOCK_STYLE_COUNT) gSet.clockStyle = 0;
  if (gSet.accent >= 9) gSet.accent = 0;
  if (gSet.tickPos > 2) gSet.tickPos = 2;
  if (gSet.tickBig > 1) gSet.tickBig = 0;
  if (gSet.tickColor > 9) gSet.tickColor = 9;
  if (gSet.tickSpeed < 1 || gSet.tickSpeed > 10) gSet.tickSpeed = 5;
  if (gSet.tickPause > 3600) gSet.tickPause = 10;
  gSet.autoMask &= (1ULL << CLOCK_STYLE_COUNT) - 1;
  if (gSet.autoSec < 10 || gSet.autoSec > 86400) gSet.autoSec = DEFAULT_AUTO_SEC;
  if (gSet.dimStart >= 1440) gSet.dimStart = DEFAULT_DIM_START;
  if (gSet.dimEnd >= 1440)   gSet.dimEnd = DEFAULT_DIM_END;
  if (gSet.alTime >= 1440) gSet.alTime = DEFAULT_ALARM_TIME;
  gSet.alDays &= 0x7F;
  if (gSet.sleigh > 2) gSet.sleigh = DEFAULT_SLEIGH;
  if (gSet.dimLevel < 5 || gSet.dimLevel > 100) gSet.dimLevel = DEFAULT_DIM_LEVEL;
  if (gSet.tz[0] == 0)   strlcpy(gSet.tz, DEFAULT_TZ, sizeof(gSet.tz));
#if BOARD_CYD
  // NVS leer (neu oder geloescht, z. B. weil der gemeinsame NVS-Bereich mit RetroCYD voll war):
  // Einstellungen aus der Sicherung ausserhalb des NVS zurueckholen, sonst wenigstens das WLAN.
  if (nvsEmpty) {
    Settings b;
    cyd::BakWifi w;
    if (cyd::bakRead(cyd::BAK_SET, &b, sizeof(Settings), STYLE_VERSION)) { gSet = b; gSetRestored = true; }
    else if (cyd::bakRead(cyd::BAK_WIFI, &w, sizeof(w)) && w.ssid[0]) {
      strlcpy(gSet.ssid, w.ssid, sizeof(gSet.ssid)); strlcpy(gSet.pass, w.pass, sizeof(gSet.pass)); gSetRestored = true;
    }
    if (gSetRestored) { gLang = gSet.lang < LANG_COUNT ? gSet.lang : 0; settingsSave(); }
  } else {                                         // Sicherung anlegen bzw. aktuell halten (schreibt nur bei Aenderung)
    cyd::BakWifi w;
    memset(&w, 0, sizeof(w));
    strlcpy(w.ssid, gSet.ssid, sizeof(w.ssid)); strlcpy(w.pass, gSet.pass, sizeof(w.pass));
    cyd::bakWrite(cyd::BAK_WIFI, &w, sizeof(w));
    cyd::bakWrite(cyd::BAK_SET, &gSet, sizeof(Settings), STYLE_VERSION);
  }
#endif
  if (sver < STYLE_VERSION) { settingsSave(); }   // umgerechnete Design-Nummern gleich speichern
  if (gSet.ntp[0] == 0)  strlcpy(gSet.ntp, DEFAULT_NTP, sizeof(gSet.ntp));
  if (gSet.host[0] == 0) strlcpy(gSet.host, DEFAULT_HOSTNAME, sizeof(gSet.host));
}

static void settingsSave() {
  prefs.begin("wuhr", false);
  prefs.putString("ssid", gSet.ssid);
  prefs.putString("pass", gSet.pass);
  prefs.putString("tz", gSet.tz);
  prefs.putString("ntp", gSet.ntp);
  prefs.putString("host", gSet.host);
  prefs.putString("webpw", gSet.webPw);
  prefs.putFloat("lat", gSet.lat);
  prefs.putFloat("lon", gSet.lon);
  prefs.putUChar("bright", gSet.bright);
  prefs.putBool("sec", gSet.seconds);
  prefs.putUChar("rot", gSet.rotation);
  prefs.putUShort("upd", gSet.updMin);
  prefs.putUChar("rkm", gSet.radarKm);
  prefs.putUChar("cs", gSet.clockStyle);
  prefs.putUChar("sver", STYLE_VERSION);
  prefs.putUChar("acc", gSet.accent);
  prefs.putBool("dimon", gSet.dimOn);
  prefs.putUShort("dims", gSet.dimStart);
  prefs.putUShort("dime", gSet.dimEnd);
  prefs.putUChar("diml", gSet.dimLevel);
  prefs.putBool("dimtv", gSet.dimTv);
  prefs.putBool("dimoff", gSet.dimOff);
  prefs.putBool("auto", gSet.autoOn);
  prefs.putBool("arnd", gSet.autoRnd);
  prefs.putUInt("amask", (uint32_t)gSet.autoMask);
  prefs.putUInt("amaskh", (uint32_t)(gSet.autoMask >> 32));
  prefs.putUInt("asec", gSet.autoSec);
  prefs.putBool("tkon", gSet.tickOn);
  prefs.putBool("tkloop", gSet.tickLoop);
  prefs.putBool("tkbg", gSet.tickBg);
  prefs.putUChar("tkpos", gSet.tickPos);
  prefs.putUChar("tkbig", gSet.tickBig);
  prefs.putUChar("tkcol", gSet.tickColor);
  prefs.putUChar("tkspd", gSet.tickSpeed);
  prefs.putUShort("tkpause", gSet.tickPause);
  prefs.putString("tk", gSet.tick);
  prefs.putBool("ntpon", gSet.ntpOn);
  prefs.putBool("bzhr", gSet.bzHour);
  prefs.putBool("bzq", gSet.bzQuiet);
  prefs.putBool("bztc", gSet.bzTouch);
  prefs.putUChar("svol", gSet.sndVol);
  prefs.putUChar("altn", gSet.alTone);
  prefs.putUChar("hrtn", gSet.hrTone);
  prefs.putUChar("sfx", gSet.sndFx);
  prefs.putBool("alon", gSet.alOn);
  prefs.putUShort("alt", gSet.alTime);
  prefs.putUChar("ald", gSet.alDays);
  prefs.putBool("ufo", gSet.ufoOn);
  prefs.putUChar("sled", gSet.sleigh);
  prefs.putBool("nyeauto", gSet.nyeAuto);
  prefs.putBool("holauto", gSet.holAuto);
  prefs.putUChar("fine", gSet.fine);
  prefs.putUChar("panel", gSet.panel);
  prefs.putUChar("pflg", gSet.pflags);
  prefs.putUChar("ledm", gSet.ledMode);
  prefs.putUInt("ledc", gSet.ledCol);
  prefs.putUChar("ledb", gSet.ledBri);
  prefs.putUChar("ledt", gSet.ledTime);
  prefs.putUChar("ledh", gSet.ledHint);
  prefs.putUChar("calbl", gSet.calBl);
  prefs.putUChar("calf", gSet.calFlags);
  prefs.putUChar("calp", gSet.calPop);
  prefs.putUChar("calt", gSet.calTick);
  prefs.putUChar("lang", gSet.lang);
  gLang = gSet.lang;
  prefs.end();
#if BOARD_CYD
  // Sicherung ausserhalb des NVS (siehe cyd_shared.h); schreibt nur, wenn sich etwas geaendert hat
  cyd::BakWifi w;
  memset(&w, 0, sizeof(w));
  strlcpy(w.ssid, gSet.ssid, sizeof(w.ssid)); strlcpy(w.pass, gSet.pass, sizeof(w.pass));
  cyd::bakWrite(cyd::BAK_WIFI, &w, sizeof(w));
  cyd::bakWrite(cyd::BAK_SET, &gSet, sizeof(Settings), STYLE_VERSION);
#endif
}

// Nur die Helligkeit schreiben (haeufig geaendert, schont den Flash)
static void settingsSaveBrightness() {
  prefs.begin("wuhr", false);
  prefs.putUChar("bright", gSet.bright);
  prefs.end();
}

static void settingsFactoryReset() {
  prefs.begin("wuhr", false);
  prefs.clear();
  prefs.end();
#if BOARD_CYD
  cyd::bakClear();               // sonst wuerden die alten Einstellungen beim Start wiederhergestellt
#endif
}
